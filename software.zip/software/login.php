<?php
include 'conexion.php';

$nombre = $_POST['nombre_usuario'];
$contrasena = $_POST['contrasena'];

// Consulta que trae la contraseña encriptada, el nombre del usuario y el rol
$stmt = $conexion->prepare("SELECT nombre_usuario, contrasena, rol_usuario FROM usuarios WHERE nombre_usuario = ?");
$stmt->bind_param("s", $nombre);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $fila = $resultado->fetch_assoc();
    $hash = $fila['contrasena'];

    // Verificamos la contraseña encriptada
    if (password_verify($contrasena, $hash)) {
        session_start();
        $_SESSION['usuario'] = $fila['nombre_usuario'];  // nombre correcto del usuario
        $_SESSION['rol_usuario'] = $fila['rol_usuario'];         // rol guardado en la base

        header("Location: principal.php");
        exit();
    }
}

// Si falló la autenticación
echo "Usuario o contraseña incorrectos.";

$stmt->close();
$conexion->close();
?>
