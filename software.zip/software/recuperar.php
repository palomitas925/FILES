<?php
include 'conexion.php';

$codigo = $_POST['codigo_registro'];
$nueva_contrasena = password_hash($_POST['nueva_contrasena'], PASSWORD_DEFAULT);

$stmt = $conexion->prepare("UPDATE usuarios SET contrasena = ? WHERE codigo_registro = ?");
$stmt->bind_param("ss", $nueva_contrasena, $codigo);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    echo "Contraseña actualizada con éxito.";
} else {
    echo "Código de registro no válido.";
}

$stmt->close();
$conexion->close();
?>
