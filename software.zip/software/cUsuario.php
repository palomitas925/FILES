<?php
session_start();
require 'vendor/autoload.php'; // Para generar PDFs (requiere composer)

// Verificar si el usuario tiene permisos de administrador
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

// Configuración de la base de datos
$db_config = [
    'servername' => 'localhost',
    'username' => 'root',
    'password' => '',
    'dbname' => 'admin'
];

// Establecer conexión
function getDBConnection() {
    global $db_config;
    $conn = new mysqli($db_config['servername'], $db_config['username'], $db_config['password'], $db_config['dbname']);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    return $conn;
}

// Obtener lista de usuarios
function obtenerUsuarios() {
    $conn = getDBConnection();
    $sql = "SELECT id_usuario, nombre_usuario, rol_usuario, codigo_registro, fecha_creacion, ultimo_acceso FROM usuarios";
    $result = $conn->query($sql);
    $usuarios = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $usuarios[] = $row;
        }
    }
    $conn->close();
    return $usuarios;
}

// Obtener datos de un usuario específico
function obtenerUsuario($id) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT id_usuario, nombre_usuario, rol_usuario, codigo_registro, fecha_creacion, ultimo_acceso FROM usuarios WHERE id_usuario = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();
    $conn->close();
    return $usuario;
}

// Procesar acciones CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = getDBConnection();
    $response = ['success' => false, 'message' => ''];
    
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'get_user':
                    // Endpoint para obtener datos de usuario (para AJAX)
                    if (empty($_POST['id'])) {
                        throw new Exception("ID de usuario requerido");
                    }
                    $usuario = obtenerUsuario($_POST['id']);
                    if ($usuario) {
                        echo json_encode($usuario);
                    } else {
                        echo json_encode(['error' => 'Usuario no encontrado']);
                    }
                    exit;
                    
                case 'editar':
                    if (empty($_POST['id_usuario'])) {
                        throw new Exception("ID de usuario requerido");
                    }
                    
                    // Validar campos
                    $requiredFields = ['nombre_usuario', 'rol_usuario', 'codigo_registro'];
                    foreach ($requiredFields as $field) {
                        if (empty($_POST[$field])) {
                            throw new Exception("El campo $field es requerido");
                        }
                    }
                    
                    // Preparar consulta de actualización
                    $sql = "UPDATE usuarios SET nombre_usuario = ?, rol_usuario = ?, codigo_registro = ?";
                    $params = [$_POST['nombre_usuario'], $_POST['rol_usuario'], $_POST['codigo_registro']];
                    $types = "sss";
                    
                    // Si se proporcionó una nueva contraseña
                    if (!empty($_POST['contrasena'])) {
                        if (strlen($_POST['contrasena']) < 8) {
                            throw new Exception("La contraseña debe tener al menos 8 caracteres");
                        }
                        $sql .= ", contrasena = ?";
                        $params[] = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
                        $types .= "s";
                    }
                    
                    $sql .= " WHERE id_usuario = ?";
                    $params[] = $_POST['id_usuario'];
                    $types .= "i";
                    
                    $stmt = $conn->prepare($sql);
                    if (!$stmt) {
                        throw new Exception("Error al preparar la consulta: " . $conn->error);
                    }
                    $stmt->bind_param($types, ...$params);
                    
                    if ($stmt->execute()) {
                        $response['success'] = true;
                        $response['message'] = "Usuario actualizado correctamente";
                    } else {
                        throw new Exception("Error al actualizar el usuario: " . $stmt->error);
                    }
                    break;
                    
                case 'eliminar':
                    if (empty($_POST['id_usuario'])) {
                        throw new Exception("ID de usuario requerido");
                    }
                    
                    // Verificar que no se está eliminando a sí mismo
                    if (isset($_SESSION['id_usuario']) && $_POST['id_usuario'] == $_SESSION['id_usuario']) {
                        throw new Exception("No puedes eliminar tu propia cuenta");
                    }
                    
                    // Eliminar usuario
                    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id_usuario = ?");
                    if (!$stmt) {
                        throw new Exception("Error al preparar la consulta: " . $conn->error);
                    }
                    $stmt->bind_param("i", $_POST['id_usuario']);
                    
                    if ($stmt->execute()) {
                        $response['success'] = true;
                        $response['message'] = "Usuario eliminado correctamente";
                    } else {
                        throw new Exception("Error al eliminar el usuario: " . $stmt->error);
                    }
                    break;
                    
                case 'exportar_pdf':
                    // Obtener todos los usuarios
                    $usuarios = obtenerUsuarios();
                    
                    // Crear PDF
                    $pdf = new FPDF();
                    $pdf->AddPage();
                    $pdf->SetFont('Arial', 'B', 16);
                    $pdf->Cell(0, 10, 'Reporte de Usuarios', 0, 1, 'C');
                    $pdf->Ln(10);
                    
                    // Encabezados de tabla
                    $pdf->SetFont('Arial', 'B', 10);
                    $pdf->Cell(10, 10, 'ID', 1);
                    $pdf->Cell(40, 10, 'Nombre', 1);
                    $pdf->Cell(30, 10, 'Rol', 1);
                    $pdf->Cell(30, 10, 'Código', 1);
                    $pdf->Cell(40, 10, 'Creación', 1);
                    $pdf->Cell(40, 10, 'Último Acceso', 1);
                    $pdf->Ln();
                    
                    // Contenido de tabla
                    $pdf->SetFont('Arial', '', 8);
                    foreach ($usuarios as $usuario) {
                        $pdf->Cell(10, 10, $usuario['id_usuario'], 1);
                        $pdf->Cell(40, 10, $usuario['nombre_usuario'], 1);
                        $pdf->Cell(30, 10, $usuario['rol_usuario'], 1);
                        $pdf->Cell(30, 10, $usuario['codigo_registro'], 1);
                        $pdf->Cell(40, 10, $usuario['fecha_creacion'], 1);
                        $pdf->Cell(40, 10, $usuario['ultimo_acceso'] ?? 'Nunca', 1);
                        $pdf->Ln();
                    }
                    
                    // Salida del PDF
                    $pdf->Output('D', 'reporte_usuarios_'.date('Y-m-d').'.pdf');
                    exit;
                    break;
            }
        }
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
    }
    
    $conn->close();
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

$usuarios = obtenerUsuarios();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Usuarios</title>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #34495e;
            --accent-color: #3498db;
            --light-color: #ecf0f1;
            --danger-color: #e74c3c;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --border-radius: 4px;
            --box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--light-color);
        }
        
        .search-bar {
            display: flex;
            margin-bottom: 20px;
            gap: 10px;
        }
        
        .search-bar input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
        }
        
        .search-bar button {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-search {
            background-color: var(--accent-color);
            color: white;
        }
        
        .btn-clear {
            background-color: var(--light-color);
            color: var(--secondary-color);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: var(--primary-color);
            color: white;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .action-btns {
            display: flex;
            gap: 5px;
        }
        
        .btn-edit {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-delete {
            background-color: var(--danger-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-export {
            background-color: var(--success-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .footer-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        
        .btn-main {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-add {
            background-color: var(--success-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-refresh {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        hr {
            border: 0;
            height: 1px;
            background-color: #ddd;
            margin: 20px 0;
        }
        
        .no-data {
            text-align: center;
            padding: 20px;
            color: #777;
            font-style: italic;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 80%;
            max-width: 600px;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        
        .modal-title {
            font-size: 1.5rem;
            color: var(--primary-color);
        }
        
        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
        }
        
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-primary {
            background-color: var(--accent-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: var(--light-color);
            color: var(--secondary-color);
        }
        
        .info-text {
            font-size: 0.8rem;
            color: #666;
            font-style: italic;
        }
        
        .error-message {
            color: var(--danger-color);
            font-size: 0.8rem;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ADMINISTRACIÓN DE USUARIOS</h1>
        
        <div class="search-bar">
            <input type="text" id="search-input" placeholder="Buscar usuario...">
            <button class="btn-search" id="btn-search">Buscar</button>
            <button class="btn-clear" id="btn-clear">Limpiar</button>
        </div>
        
        <hr>
        
        <table id="usuarios-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre de Usuario</th>
                    <th>Rol</th>
                    <th>Código de Registro</th>
                    <th>Fecha de Creación</th>
                    <th>Último Acceso</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($usuarios) > 0): ?>
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr data-id="<?= htmlspecialchars($usuario['id_usuario']) ?>">
                            <td><?= htmlspecialchars($usuario['id_usuario']) ?></td>
                            <td><?= htmlspecialchars($usuario['nombre_usuario']) ?></td>
                            <td><?= htmlspecialchars($usuario['rol_usuario']) ?></td>
                            <td><?= htmlspecialchars($usuario['codigo_registro']) ?></td>
                            <td><?= htmlspecialchars($usuario['fecha_creacion']) ?></td>
                            <td><?= htmlspecialchars($usuario['ultimo_acceso'] ?? 'Nunca') ?></td>
                            <td class="action-btns">
                                <button class="btn-edit" onclick="editarUsuario(<?= htmlspecialchars($usuario['id_usuario']) ?>)">Editar</button>
                                <button class="btn-delete" onclick="confirmarEliminar(<?= htmlspecialchars($usuario['id_usuario']) ?>)">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="no-data">No se encontraron usuarios registrados</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div class="footer-actions">
            <button class="btn-main" onclick="window.location.href='principal.php'">Regresar al Principal</button>
            <div>
                <button class="btn-export" onclick="exportarPDF()">Exportar a PDF</button>
                <button class="btn-refresh" onclick="actualizarTabla()">Actualizar Lista</button>
            </div>
        </div>
    </div>

    <!-- Modal para editar usuario -->
    <div id="usuario-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="modal-title">Editar Usuario</h2>
                <span class="close">&times;</span>
            </div>
            <form id="usuario-form">
                <input type="hidden" id="id_usuario" name="id_usuario" value="">
                <input type="hidden" name="action" value="editar">
                
                <div class="form-group">
                    <label for="nombre_usuario" class="form-label">Nombre de Usuario</label>
                    <input type="text" id="nombre_usuario" name="nombre_usuario" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="contrasena" class="form-label">Contraseña (dejar en blanco para no cambiar)</label>
                    <input type="password" id="contrasena" name="contrasena" class="form-control">
                    <p class="info-text">La contraseña debe tener al menos 8 caracteres</p>
                    <div id="contrasena-error" class="error-message" style="display: none;"></div>
                </div>
                
                <div class="form-group">
                    <label for="rol_usuario" class="form-label">Rol</label>
                    <select id="rol_usuario" name="rol_usuario" class="form-control" required>
                        <option value="admin">Administrador</option>
                        <option value="user">Usuario</option>
                        <option value="editor">Editor</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="codigo_registro" class="form-label">Código de Registro</label>
                    <input type="text" id="codigo_registro" name="codigo_registro" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Fecha de Creación</label>
                    <input type="text" id="fecha_creacion" class="form-control" disabled>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Último Acceso</label>
                    <input type="text" id="ultimo_acceso" class="form-control" disabled>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="btn-cancelar">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Variables globales
        const modal = document.getElementById('usuario-modal');
        const span = document.getElementsByClassName('close')[0];
        const form = document.getElementById('usuario-form');
        const btnCancelar = document.getElementById('btn-cancelar');
        const contrasenaInput = document.getElementById('contrasena');
        const contrasenaError = document.getElementById('contrasena-error');
        
        // Cerrar modal al hacer clic en la X
        span.onclick = function() {
            modal.style.display = 'none';
        }
        
        // Cerrar modal al hacer clic fuera del contenido
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
        
        // Cancelar formulario
        btnCancelar.onclick = function() {
            modal.style.display = 'none';
        }
        
        // Validar contraseña
        contrasenaInput.addEventListener('input', function() {
            if (this.value.length > 0 && this.value.length < 8) {
                contrasenaError.textContent = 'La contraseña debe tener al menos 8 caracteres';
                contrasenaError.style.display = 'block';
            } else {
                contrasenaError.style.display = 'none';
            }
        });
        
        // Editar usuario
        function editarUsuario(id) {
            fetch('usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=get_user&id=${id}`
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error en la respuesta del servidor');
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    throw new Error(data.error);
                }
                
                document.getElementById('modal-title').textContent = 'Editar Usuario';
                document.getElementById('id_usuario').value = data.id_usuario;
                document.getElementById('nombre_usuario').value = data.nombre_usuario;
                document.getElementById('rol_usuario').value = data.rol_usuario;
                document.getElementById('codigo_registro').value = data.codigo_registro;
                document.getElementById('fecha_creacion').value = data.fecha_creacion;
                document.getElementById('ultimo_acceso').value = data.ultimo_acceso || 'Nunca';
                
                modal.style.display = 'block';
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al cargar los datos del usuario: ' + error.message);
            });
        }
        
        // Confirmar eliminación
        function confirmarEliminar(id) {
            if (confirm('¿Está seguro de eliminar este usuario? Esta acción no se puede deshacer.')) {
                eliminarUsuario(id);
            }
        }
        
        // Eliminar usuario
        function eliminarUsuario(id) {
            const formData = new FormData();
            formData.append('action', 'eliminar');
            formData.append('id_usuario', id);
            
            fetch('usuarios.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error en la respuesta del servidor');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    actualizarTabla();
                } else {
                    throw new Error(data.message || 'Error al eliminar el usuario');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert(error.message);
            });
        }
        
        // Exportar a PDF
        function exportarPDF() {
            const formData = new FormData();
            formData.append('action', 'exportar_pdf');
            
            fetch('usuarios.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al generar el PDF');
                }
                return response.blob();
            })
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `reporte_usuarios_${new Date().toISOString().split('T')[0]}.pdf`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al exportar a PDF: ' + error.message);
            });
        }
        
        // Enviar formulario de edición
        form.onsubmit = function(e) {
            e.preventDefault();
            
            // Validar contraseña si se proporcionó
            if (contrasenaInput.value.length > 0 && contrasenaInput.value.length < 8) {
                contrasenaError.textContent = 'La contraseña debe tener al menos 8 caracteres';
                contrasenaError.style.display = 'block';
                return;
            }
            
            const formData = new FormData(form);
            
            fetch('usuarios.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error en la respuesta del servidor');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    modal.style.display = 'none';
                    actualizarTabla();
                } else {
                    throw new Error(data.message || 'Error al actualizar el usuario');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert(error.message);
            });
        }
        
        // Actualizar tabla
        function actualizarTabla() {
            location.reload();
        }
        
        // Buscar usuarios
        document.getElementById('btn-search').addEventListener('click', function() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const rows = document.querySelectorAll('#usuarios-table tbody tr');
            
            rows.forEach(row => {
                if (row.querySelector('td.no-data')) return;
                
                let found = false;
                const cells = row.querySelectorAll('td');
                
                for (let i = 0; i < cells.length - 1; i++) {
                    if (cells[i].textContent.toLowerCase().includes(searchTerm)) {
                        found = true;
                        break;
                    }
                }
                
                row.style.display = found ? '' : 'none';
            });
        });
        
        // Limpiar búsqueda
        document.getElementById('btn-clear').addEventListener('click', function() {
            document.getElementById('search-input').value = '';
            const rows = document.querySelectorAll('#usuarios-table tbody tr');
            rows.forEach(row => row.style.display = '');
        });
    </script>
</body>
</html>