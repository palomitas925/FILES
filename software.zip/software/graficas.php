<?php
// graficas.php
require_once 'conexion.php';

$action = $_GET['action'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráficas Analíticas</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --color-primary: #3498db;
            --color-success: #2ecc71;
            --color-danger: #e74c3c;
            --color-warning: #f39c12;
            --color-dark: #2c3e50;
            --color-light: #ecf0f1;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }
        .graficas-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 30px;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .graficas-header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eee;
        }
        .graficas-header h1 {
            color: var(--color-dark);
            font-weight: 700;
            margin-bottom: 10px;
        }
        .graficas-header p {
            color: #7f8c8d;
            font-size: 1.1rem;
        }
        .btn-group-graficas {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 30px;
            justify-content: center;
        }
        .btn-grafica {
            padding: 12px 24px;
            border: none;
            border-radius: 30px;
            font-weight: 500;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            cursor: pointer;
        }
        .btn-grafica:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 10px rgba(0,0,0,0.15);
        }
        .btn-inventario {
            background-color: var(--color-primary);
            color: white;
        }
        .btn-clientes {
            background-color: var(--color-success);
            color: white;
        }
        .btn-ventas {
            background-color: var(--color-danger);
            color: white;
        }
        .btn-pedidos {
            background-color: var(--color-warning);
            color: white;
        }
        .chart-container {
            margin-top: 30px;
            padding: 25px;
            border: 1px solid #eee;
            border-radius: 12px;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: none;
        }
        .chart-title {
            text-align: center;
            margin-bottom: 25px;
            color: var(--color-dark);
            font-weight: 600;
            font-size: 1.3rem;
        }
        .chart-wrapper {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
            min-height: 400px;
        }
        .loading {
            text-align: center;
            font-style: italic;
            color: #7f8c8d;
            padding: 30px;
            font-size: 1.1rem;
        }
        .back-button {
            margin-bottom: 25px;
        }
        .filter-section {
            background-color: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .filter-title {
            font-weight: 600;
            color: var(--color-dark);
            margin-bottom: 15px;
        }
        @media (max-width: 768px) {
            .graficas-container {
                padding: 20px;
            }
            .btn-grafica {
                padding: 10px 15px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="graficas-container">
        <div class="back-button">
            <a href="reportes.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Volver a Reportes
            </a>
        </div>
        
        <div class="graficas-header">
            <h1>Análisis Gráfico</h1>
            <p>Visualización interactiva de datos empresariales</p>
        </div>
        
        <div class="btn-group-graficas">
            <button class="btn-grafica btn-inventario" onclick="showChart('productos-barras')">
                <i class="bi bi-bar-chart"></i> Inventario (Barras)
            </button>
            <button class="btn-grafica btn-inventario" onclick="showChart('productos-pastel')">
                <i class="bi bi-pie-chart"></i> Inventario (Pastel)
            </button>
            <button class="btn-grafica btn-clientes" onclick="showChart('clientes-barras')">
                <i class="bi bi-bar-chart"></i> Clientes (Barras)
            </button>
            <button class="btn-grafica btn-clientes" onclick="showChart('clientes-pastel')">
                <i class="bi bi-pie-chart"></i> Clientes (Pastel)
            </button>
            <button class="btn-grafica btn-ventas" onclick="showChart('ventas-barras')">
                <i class="bi bi-bar-chart"></i> Ventas (Barras)
            </button>
            <button class="btn-grafica btn-ventas" onclick="showChart('ventas-pastel')">
                <i class="bi bi-pie-chart"></i> Ventas (Pastel)
            </button>
            <button class="btn-grafica btn-pedidos" onclick="showChart('pedidos-barras')">
                <i class="bi bi-bar-chart"></i> Pedidos (Barras)
            </button>
            <button class="btn-grafica btn-pedidos" onclick="showChart('pedidos-pastel')">
                <i class="bi bi-pie-chart"></i> Pedidos (Pastel)
            </button>
        </div>
        
        <!-- Filtros -->
        <div class="filter-section">
            <h5 class="filter-title">Filtros Avanzados</h5>
            <div class="row">
                <div class="col-md-3">
                    <label for="fecha-inicio" class="form-label">Fecha Inicio:</label>
                    <input type="date" id="fecha-inicio" class="form-control">
                </div>
                <div class="col-md-3">
                    <label for="fecha-fin" class="form-label">Fecha Fin:</label>
                    <input type="date" id="fecha-fin" class="form-control">
                </div>
                <div class="col-md-3">
                    <label for="tipo-agrupacion" class="form-label">Agrupación:</label>
                    <select id="tipo-agrupacion" class="form-select">
                        <option value="dia">Por Día</option>
                        <option value="mes" selected>Por Mes</option>
                        <option value="anio">Por Año</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button onclick="applyFilters()" class="btn btn-primary w-100">
                        <i class="bi bi-funnel"></i> Aplicar Filtros
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Contenedores de gráficas -->
        <div id="productos-barras" class="chart-container">
            <h2 class="chart-title">Productos más vendidos</h2>
            <div class="chart-wrapper">
                <canvas id="chartProductosBarras"></canvas>
                <p class="loading" id="loading-productos-barras">Cargando datos de productos...</p>
            </div>
        </div>
        
        <div id="productos-pastel" class="chart-container">
            <h2 class="chart-title">Distribución de productos vendidos</h2>
            <div class="chart-wrapper">
                <canvas id="chartProductosPastel"></canvas>
                <p class="loading" id="loading-productos-pastel">Cargando distribución de productos...</p>
            </div>
        </div>
        
        <div id="clientes-barras" class="chart-container">
            <h2 class="chart-title">Registro de clientes por periodo</h2>
            <div class="chart-wrapper">
                <canvas id="chartClientesBarras"></canvas>
                <p class="loading" id="loading-clientes-barras">Cargando datos de clientes...</p>
            </div>
        </div>
        
        <div id="clientes-pastel" class="chart-container">
            <h2 class="chart-title">Distribución de clientes por dominio de correo</h2>
            <div class="chart-wrapper">
                <canvas id="chartClientesPastel"></canvas>
                <p class="loading" id="loading-clientes-pastel">Cargando distribución de clientes...</p>
            </div>
        </div>
        
        <div id="ventas-barras" class="chart-container">
            <h2 class="chart-title">Ventas por periodo</h2>
            <div class="chart-wrapper">
                <canvas id="chartVentasBarras"></canvas>
                <p class="loading" id="loading-ventas-barras">Cargando datos de ventas...</p>
            </div>
        </div>
        
        <div id="ventas-pastel" class="chart-container">
            <h2 class="chart-title">Métodos de pago utilizados</h2>
            <div class="chart-wrapper">
                <canvas id="chartVentasPastel"></canvas>
                <p class="loading" id="loading-ventas-pastel">Cargando métodos de pago...</p>
            </div>
        </div>
        
        <div id="pedidos-barras" class="chart-container">
            <h2 class="chart-title">Pedidos por periodo</h2>
            <div class="chart-wrapper">
                <canvas id="chartPedidosBarras"></canvas>
                <p class="loading" id="loading-pedidos-barras">Cargando datos de pedidos...</p>
            </div>
        </div>
        
        <div id="pedidos-pastel" class="chart-container">
            <h2 class="chart-title">Estados de los pedidos</h2>
            <div class="chart-wrapper">
                <canvas id="chartPedidosPastel"></canvas>
                <p class="loading" id="loading-pedidos-pastel">Cargando estados de pedidos...</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Variables para almacenar los objetos Chart
        let charts = {};
        let currentChart = '';
        
        // Función para mostrar u ocultar gráficas
        function showChart(chartId) {
            // Ocultar todas las gráficas primero
            document.querySelectorAll('.chart-container').forEach(el => {
                el.style.display = 'none';
            });
            
            // Mostrar la gráfica seleccionada
            const chartElement = document.getElementById(chartId);
            chartElement.style.display = 'block';
            currentChart = chartId;
            
            // Mostrar mensaje de carga
            document.getElementById('loading-' + chartId).style.display = 'block';
            
            // Si el canvas no existe, crearlo
            const canvasId = 'chart' + chartId.split('-').map(word => 
                word.charAt(0).toUpperCase() + word.slice(1)).join('');
            
            let canvas = document.getElementById(canvasId);
            if (!canvas) {
                canvas = document.createElement('canvas');
                canvas.id = canvasId;
                document.querySelector(`#${chartId} .chart-wrapper`).appendChild(canvas);
            }
            
            // Si la gráfica no se ha creado aún, crearla
            if (!charts[chartId]) {
                createChart(chartId);
            } else {
                // Si ya existe, ocultar el mensaje de carga
                document.getElementById('loading-' + chartId).style.display = 'none';
            }
        }
        
        // Función para aplicar filtros
        function applyFilters() {
            const fechaInicio = document.getElementById('fecha-inicio').value;
            const fechaFin = document.getElementById('fecha-fin').value;
            const agrupacion = document.getElementById('tipo-agrupacion').value;
            
            if (currentChart) {
                createChart(currentChart, fechaInicio, fechaFin, agrupacion);
            } else {
                createChart('productos-barras', fechaInicio, fechaFin, agrupacion);
            }
        }
        
        // Función para crear gráficas
        function createChart(chartId, fechaInicio = null, fechaFin = null, agrupacion = 'mes') {
            // Mostrar mensaje de carga
            document.getElementById('loading-' + chartId).style.display = 'block';
            
            // Construir URL de la solicitud
            let url = `get_data.php?action=${chartId.replace('-', '_')}`;
            
            if (fechaInicio) url += `&fecha_inicio=${fechaInicio}`;
            if (fechaFin) url += `&fecha_fin=${fechaFin}`;
            if (agrupacion) url += `&agrupacion=${agrupacion}`;
            
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        throw new Error(data.error);
                    }
                    
                    const ctx = document.getElementById(`chart${chartId.split('-').map(word => 
                        word.charAt(0).toUpperCase() + word.slice(1)).join('')}`).getContext('2d');
                    
                    // Destruir gráfica existente si hay una
                    if (charts[chartId]) {
                        charts[chartId].destroy();
                    }
                    
                    // Configuración común para gráficas
                    const commonOptions = {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'top',
                                labels: {
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                enabled: true,
                                mode: 'index',
                                intersect: false,
                                bodyFont: {
                                    size: 14
                                },
                                titleFont: {
                                    size: 16
                                }
                            },
                            title: {
                                display: true,
                                text: document.querySelector(`#${chartId} .chart-title`).textContent,
                                font: {
                                    size: 18,
                                    weight: 'bold'
                                },
                                padding: {
                                    top: 10,
                                    bottom: 20
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    font: {
                                        size: 12
                                    }
                                }
                            },
                            x: {
                                ticks: {
                                    font: {
                                        size: 12
                                    }
                                }
                            }
                        }
                    };
                    
                    // Determinar colores según el tipo de gráfica
                    let backgroundColor, borderColor;
                    
                    if (chartId.includes('productos')) {
                        backgroundColor = 'rgba(52, 152, 219, 0.7)';
                        borderColor = 'rgba(52, 152, 219, 1)';
                    } else if (chartId.includes('clientes')) {
                        backgroundColor = 'rgba(46, 204, 113, 0.7)';
                        borderColor = 'rgba(46, 204, 113, 1)';
                    } else if (chartId.includes('ventas')) {
                        backgroundColor = 'rgba(231, 76, 60, 0.7)';
                        borderColor = 'rgba(231, 76, 60, 1)';
                    } else {
                        backgroundColor = 'rgba(243, 156, 18, 0.7)';
                        borderColor = 'rgba(243, 156, 18, 1)';
                    }
                    
                    // Crear gráfica según el tipo
                    if (chartId.includes('-pastel')) {
                        // Colores para gráficas de pastel
                        const backgroundColors = [
                            'rgba(52, 152, 219, 0.7)',
                            'rgba(46, 204, 113, 0.7)',
                            'rgba(231, 76, 60, 0.7)',
                            'rgba(243, 156, 18, 0.7)',
                            'rgba(155, 89, 182, 0.7)',
                            'rgba(26, 188, 156, 0.7)',
                            'rgba(211, 84, 0, 0.7)',
                            'rgba(52, 73, 94, 0.7)'
                        ];
                        
                        charts[chartId] = new Chart(ctx, {
                            type: 'pie',
                            data: {
                                labels: data.labels,
                                datasets: [{
                                    data: data.values,
                                    backgroundColor: backgroundColors,
                                    borderWidth: 1
                                }]
                            },
                            options: commonOptions
                        });
                    } else {
                        charts[chartId] = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels: data.labels,
                                datasets: [{
                                    label: document.querySelector(`#${chartId} .chart-title`).textContent,
                                    data: data.values,
                                    backgroundColor: backgroundColor,
                                    borderColor: borderColor,
                                    borderWidth: 1
                                }]
                            },
                            options: commonOptions
                        });
                    }
                    
                    // Ocultar mensaje de carga
                    document.getElementById('loading-' + chartId).style.display = 'none';
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('loading-' + chartId).textContent = 
                        'Error al cargar los datos: ' + error.message;
                });
        }
        
        // Mostrar gráfica basada en el parámetro action si existe
        const urlParams = new URLSearchParams(window.location.search);
        const actionParam = urlParams.get('action');
        
        if (actionParam) {
            const chartMap = {
                'productos_barras': 'productos-barras',
                'productos_pastel': 'productos-pastel',
                'clientes_barras': 'clientes-barras',
                'clientes_pastel': 'clientes-pastel',
                'ventas_barras': 'ventas-barras',
                'ventas_pastel': 'ventas-pastel',
                'pedidos_barras': 'pedidos-barras',
                'pedidos_pastel': 'pedidos-pastel'
            };
            
            if (chartMap[actionParam]) {
                showChart(chartMap[actionParam]);
            }
        } else {
            // Mostrar la primera gráfica por defecto si no hay parámetro
            showChart('productos-barras');
        }
        
        // Establecer fechas por defecto (últimos 6 meses)
        const today = new Date();
        const sixMonthsAgo = new Date();
        sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
        
        document.getElementById('fecha-inicio').valueAsDate = sixMonthsAgo;
        document.getElementById('fecha-fin').valueAsDate = today;
    </script>
</body>
</html>