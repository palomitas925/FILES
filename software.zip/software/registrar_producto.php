<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Productos</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 100%;
            max-width: 500px;
        }
        
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
            font-size: 24px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }
        
        input[type="text"],
        input[type="number"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        textarea {
            height: 80px;
            resize: vertical;
        }
        
        .btn-submit {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        
        .btn-submit:hover {
            background-color: #45a049;
        }
        
        .status-message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 4px;
            text-align: center;
        }
        
        .success {
            background-color: #dff0d8;
            color: #3c763d;
        }
        
        .error {
            background-color: #f2dede;
            color: #a94442;
        }
        
        /* Estilo para el nuevo botón de regresar */
        .btn-back {
            display: block;
            margin-top: 15px;
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .btn-back:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registrar Productos</h1>
        <form action="Insert_Registro.php" method="POST" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="nombre_producto">Nombre del producto:</label>
                <input type="text" id="nombre_producto" name="nombre_producto" required>
            </div>
            
            <div class="form-group">
                <label for="descripcion">Descripción:</label>
                <textarea id="descripcion" name="descripcion" required></textarea>
            </div>
            
            <div class="form-group">
                <label for="variedad">Variedad:</label>
                <input type="text" id="variedad" name="variedad" required>
            </div>
            
            <div class="form-group">
                <label for="stock">stock de producto:</label>
                <input type="number" id="stock" name="stock" min="0" required>
            </div>
            
            <div class="form-group">
                <label for="precio_unitario">Precio Unitario:</label>
                <input type="number" id="precio_unitario" name="precio_unitario" min="0" step="0.01" required>
            </div>
            
            <div class="form-group">
                <label for="estado">Estado:</label>
                <select id="estado" name="estado" required>
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                    <option value="agotado">Agotado</option>
                </select>
            </div>
            
            <button type="submit" class="btn-submit">Registrar</button>
            
            <!-- Botón de regresar añadido aquí -->
            <a href="inventario.php" class="btn-back">Regresar al Inventario</a>
        </form>
        
        <?php
        if (isset($_GET['status'])) {
            $message = "";
            $class = "";
            
            if ($_GET['status'] === 'success') {
                $message = "Producto registrado exitosamente!";
                $class = "success";
            } elseif ($_GET['status'] === 'error') {
                $message = "Error al registrar el producto. " . 
                          (isset($_GET['message']) ? htmlspecialchars($_GET['message']) : "");
                $class = "error";
            }
            
            echo "<div class='status-message $class'>$message</div>";
        }
        ?>
    </div>

    <script>
    function validateForm() {
        // Validar precio
        const precio = parseFloat(document.getElementById('precio_unitario').value);
        if (precio <= 0) {
            alert('El precio debe ser mayor que cero');
            return false;
        }
        
        // Validar stock
        const stock = parseInt(document.getElementById('stock').value);
        if (stock < 0) {
            alert('La stock no puede ser negativa');
            return false;
        }
        
        return true;
    }
    </script>
</body>
</html>