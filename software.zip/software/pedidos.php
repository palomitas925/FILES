<?php
// Configuración de la base de datos
$db_config = [
    'servername' => 'localhost',
    'username' => 'root',
    'password' => '',
    'dbname' => 'admin'
];

// Establecer conexión
function getDBConnection() {
    global $db_config;
    $conn = new mysqli($db_config['servername'], $db_config['username'], $db_config['password'], $db_config['dbname']);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    return $conn;
}

// Obtener clientes para select
function getClientes() {
    $conn = getDBConnection();
    $sql = "SELECT id_cliente, nombre FROM clientes";
    $result = $conn->query($sql);
    $clientes = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $clientes[] = $row;
        }
    }
    $conn->close();
    return $clientes;
}

// Obtener productos disponibles
function getProductosDisponibles() {
    $conn = getDBConnection();
    $sql = "SELECT id_producto, nombre_producto, stock FROM productos WHERE stock > 0";
    $result = $conn->query($sql);
    $productos = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $productos[] = $row;
        }
    }
    $conn->close();
    return $productos;
}

// Procesar acciones CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = getDBConnection();
    $response = ['success' => false, 'message' => ''];
    
    try {
        if (isset($_POST['action'])) {
            // Validar datos antes de procesar
            $requiredFields = ['id_cliente', 'fecha_pedido', 'fecha_entrega', 'estado', 'id_producto', 'cantidad'];
            foreach ($requiredFields as $field) {
                if (empty($_POST[$field])) {
                    throw new Exception("El campo $field es requerido");
                }
            }
            
            // Convertir fechas al formato correcto
            $fecha_pedido = date('Y-m-d H:i:s', strtotime($_POST['fecha_pedido']));
            $fecha_entrega = date('Y-m-d', strtotime($_POST['fecha_entrega']));
            $id_producto = $_POST['id_producto'];
            $cantidad = $_POST['cantidad'];
            $estado = $_POST['estado'];
            
            // Verificar stock disponible solo si el estado no es Pendiente o Cancelado
            if ($estado !== 'Pendiente' && $estado !== 'Cancelado') {
                $stock_query = "SELECT stock, nombre_producto, precio_unitario FROM productos WHERE id_producto = ?";
                $stmt_stock = $conn->prepare($stock_query);
                $stmt_stock->bind_param("i", $id_producto);
                $stmt_stock->execute();
                $stock_result = $stmt_stock->get_result();
                
                if ($stock_result->num_rows === 0) {
                    throw new Exception("Producto no encontrado");
                }
                
                $producto = $stock_result->fetch_assoc();
                if ($producto['stock'] < $cantidad) {
                    throw new Exception("Stock insuficiente para este producto");
                }
            }
            
            switch ($_POST['action']) {
                case 'crear':
                    // Insertar pedido principal
                    $stmt_pedido = $conn->prepare("INSERT INTO Pedidos (id_cliente, fecha_pedido, fecha_entrega, estado) VALUES (?, ?, ?, ?)");
                    $stmt_pedido->bind_param("isss", 
                        $_POST['id_cliente'],
                        $fecha_pedido,
                        $fecha_entrega,
                        $estado
                    );
                    
                    if ($stmt_pedido->execute()) {
                        $id_pedido = $stmt_pedido->insert_id;
                        
                        // Insertar detalle del pedido
                        $stmt_detalle = $conn->prepare("INSERT INTO DetallePedidos (id_pedido, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
                        $stmt_detalle->bind_param("iiid", 
                            $id_pedido,
                            $id_producto,
                            $cantidad,
                            $producto['precio_unitario']
                        );
                        
                        if ($stmt_detalle->execute()) {
                            // Actualizar stock del producto solo si no es Pendiente
                            if ($estado !== 'Pendiente') {
                                $update_stock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
                                $stmt_update = $conn->prepare($update_stock);
                                $stmt_update->bind_param("ii", $cantidad, $id_producto);
                                
                                if (!$stmt_update->execute()) {
                                    throw new Exception("Error al actualizar el stock");
                                }
                            }
                            
                            // Si el estado es Completado, crear venta
                            if ($estado === 'Completado') {
                                $monto_total = $producto['precio_unitario'] * $cantidad;
                                $metodo_pago = isset($_POST['metodo_pago']) ? $_POST['metodo_pago'] : 'Efectivo';
                                $stmt_venta = $conn->prepare("INSERT INTO Ventas (id_pedido, fecha_venta, monto_total, metodo_pago, comprobante) VALUES (?, NOW(), ?, ?, 'PEDIDO')");
                                $stmt_venta->bind_param("ids", $id_pedido, $monto_total, $metodo_pago);
                                $stmt_venta->execute();
                            }
                            
                            $response['success'] = true;
                            $response['message'] = "Pedido creado correctamente";
                        } else {
                            throw new Exception("Error al crear el detalle del pedido");
                        }
                    } else {
                        throw new Exception("Error al crear el pedido");
                    }
                    break;
                    
                case 'editar':
                    if (empty($_POST['id_pedido'])) {
                        throw new Exception("ID de pedido requerido para editar");
                    }
                    
                    // Obtener datos actuales del pedido
                    $old_pedido_query = "SELECT dp.id_producto, dp.cantidad, p.estado 
                                        FROM DetallePedidos dp
                                        JOIN Pedidos p ON dp.id_pedido = p.id_pedido
                                        WHERE dp.id_pedido = ?";
                    $stmt_old = $conn->prepare($old_pedido_query);
                    $stmt_old->bind_param("i", $_POST['id_pedido']);
                    $stmt_old->execute();
                    $old_pedido = $stmt_old->get_result()->fetch_assoc();
                    
                    // Actualizar pedido principal
                    $stmt_pedido = $conn->prepare("UPDATE Pedidos SET id_cliente=?, fecha_pedido=?, fecha_entrega=?, estado=? WHERE id_pedido=?");
                    $stmt_pedido->bind_param("isssi", 
                        $_POST['id_cliente'],
                        $fecha_pedido,
                        $fecha_entrega,
                        $estado,
                        $_POST['id_pedido']
                    );
                    
                    if ($stmt_pedido->execute()) {
                        // Actualizar detalle del pedido
                        $stmt_detalle = $conn->prepare("UPDATE DetallePedidos SET id_producto=?, cantidad=?, precio_unitario=? WHERE id_pedido=?");
                        $stmt_detalle->bind_param("iidi", 
                            $id_producto,
                            $cantidad,
                            $producto['precio_unitario'],
                            $_POST['id_pedido']
                        );
                        
                        if ($stmt_detalle->execute()) {
                            // Manejo de stock basado en estados
                            $old_estado = $old_pedido['estado'];
                            $new_estado = $estado;
                            
                            // Si el estado anterior era Pendiente y el nuevo no es Pendiente o Cancelado
                            if ($old_estado === 'Pendiente' && $new_estado !== 'Pendiente' && $new_estado !== 'Cancelado') {
                                // Restar stock por primera vez
                                $update_stock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
                                $stmt_update = $conn->prepare($update_stock);
                                $stmt_update->bind_param("ii", $cantidad, $id_producto);
                                $stmt_update->execute();
                            }
                            // Si el estado anterior no era Pendiente y el nuevo es Cancelado
                            elseif ($old_estado !== 'Pendiente' && $new_estado === 'Cancelado') {
                                // Revertir stock
                                $revertir_stock = "UPDATE productos SET stock = stock + ? WHERE id_producto = ?";
                                $stmt_revertir = $conn->prepare($revertir_stock);
                                $stmt_revertir->bind_param("ii", $cantidad, $id_producto);
                                $stmt_revertir->execute();
                            }
                            // Si el estado anterior era Cancelado y el nuevo no es Cancelado
                            elseif ($old_estado === 'Cancelado' && $new_estado !== 'Cancelado') {
                                // Restar stock nuevamente
                                $update_stock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
                                $stmt_update = $conn->prepare($update_stock);
                                $stmt_update->bind_param("ii", $cantidad, $id_producto);
                                $stmt_update->execute();
                            }
                            // Si cambió el producto
                            elseif ($old_pedido['id_producto'] != $id_producto) {
                                // Revertir stock del producto anterior
                                $revertir_stock = "UPDATE productos SET stock = stock + ? WHERE id_producto = ?";
                                $stmt_revertir = $conn->prepare($revertir_stock);
                                $stmt_revertir->bind_param("ii", $old_pedido['cantidad'], $old_pedido['id_producto']);
                                $stmt_revertir->execute();
                                
                                // Restar stock del nuevo producto (solo si no es Pendiente)
                                if ($new_estado !== 'Pendiente') {
                                    $update_stock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
                                    $stmt_update = $conn->prepare($update_stock);
                                    $stmt_update->bind_param("ii", $cantidad, $id_producto);
                                    $stmt_update->execute();
                                }
                            }
                            // Si cambió la cantidad
                            elseif ($old_pedido['cantidad'] != $cantidad && $old_estado !== 'Pendiente') {
                                $diferencia = $old_pedido['cantidad'] - $cantidad;
                                $update_stock = "UPDATE productos SET stock = stock + ? WHERE id_producto = ?";
                                $stmt_update = $conn->prepare($update_stock);
                                $stmt_update->bind_param("ii", $diferencia, $id_producto);
                                $stmt_update->execute();
                            }
                            
                            // Verificar si ya existe una venta
                            $venta_query = "SELECT id_venta FROM Ventas WHERE id_pedido = ?";
                            $stmt_venta_check = $conn->prepare($venta_query);
                            $stmt_venta_check->bind_param("i", $_POST['id_pedido']);
                            $stmt_venta_check->execute();
                            $venta_result = $stmt_venta_check->get_result();

                            $monto_total = $producto['precio_unitario'] * $cantidad;
                            $metodo_pago = isset($_POST['metodo_pago']) ? $_POST['metodo_pago'] : 'Efectivo';

                            if ($venta_result->num_rows > 0) {
                                // Actualizar venta existente
                                $stmt_venta = $conn->prepare("UPDATE Ventas SET monto_total = ?, metodo_pago = ? WHERE id_pedido = ?");
                                $stmt_venta->bind_param("dsi", $monto_total, $metodo_pago, $_POST['id_pedido']);
                            } else if ($new_estado === 'Completado') {
                                // Crear nueva venta solo si el estado es Completado
                                $stmt_venta = $conn->prepare("INSERT INTO Ventas (id_pedido, fecha_venta, monto_total, metodo_pago, comprobante) VALUES (?, NOW(), ?, ?, 'PEDIDO')");
                                $stmt_venta->bind_param("ids", $_POST['id_pedido'], $monto_total, $metodo_pago);
                            }

                            if (isset($stmt_venta)) {
                                $stmt_venta->execute();
                            }
                            
                            $response['success'] = true;
                            $response['message'] = "Pedido actualizado correctamente";
                        } else {
                            throw new Exception("Error al actualizar el detalle del pedido");
                        }
                    } else {
                        throw new Exception("Error al actualizar el pedido");
                    }
                    break;
                    
                case 'eliminar':
                    if (empty($_POST['id_pedido'])) {
                        throw new Exception("ID de pedido requerido para eliminar");
                    }
                    
                    // Obtener datos del pedido para revertir stock si no es Pendiente
                    $pedido_query = "SELECT dp.id_producto, dp.cantidad, p.estado 
                                    FROM DetallePedidos dp
                                    JOIN Pedidos p ON dp.id_pedido = p.id_pedido
                                    WHERE dp.id_pedido = ?";
                    $stmt_pedido = $conn->prepare($pedido_query);
                    $stmt_pedido->bind_param("i", $_POST['id_pedido']);
                    $stmt_pedido->execute();
                    $pedido_data = $stmt_pedido->get_result()->fetch_assoc();
                    
                    // Eliminar detalle del pedido
                    $stmt_detalle = $conn->prepare("DELETE FROM DetallePedidos WHERE id_pedido=?");
                    $stmt_detalle->bind_param("i", $_POST['id_pedido']);
                    
                    // Eliminar pedido principal
                    $stmt = $conn->prepare("DELETE FROM Pedidos WHERE id_pedido=?");
                    $stmt->bind_param("i", $_POST['id_pedido']);
                    
                    if ($stmt_detalle->execute() && $stmt->execute()) {
                        // Revertir stock del producto solo si el estado no era Pendiente
                        if ($pedido_data['estado'] !== 'Pendiente') {
                            $update_stock = "UPDATE productos SET stock = stock + ? WHERE id_producto = ?";
                            $stmt_update = $conn->prepare($update_stock);
                            $stmt_update->bind_param("ii", $pedido_data['cantidad'], $pedido_data['id_producto']);
                            
                            if (!$stmt_update->execute()) {
                                throw new Exception("Error al revertir el stock");
                            }
                        }
                        
                        // Eliminar venta asociada si existe
                        $stmt_venta = $conn->prepare("DELETE FROM Ventas WHERE id_pedido = ?");
                        $stmt_venta->bind_param("i", $_POST['id_pedido']);
                        $stmt_venta->execute();
                        
                        $response['success'] = true;
                        $response['message'] = "Pedido eliminado correctamente";
                    } else {
                        throw new Exception("Error al eliminar el pedido");
                    }
                    break;
            }
        }
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
    }
    
    $conn->close();
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

function getPedidos() {
    $conn = getDBConnection();
    $sql = "SELECT p.id_pedido, p.id_cliente, c.nombre as nombre_cliente, p.fecha_pedido, 
                   p.fecha_entrega, p.estado, dp.id_producto, pr.nombre_producto as producto, 
                   dp.cantidad, dp.precio_unitario, v.metodo_pago
            FROM Pedidos p
            LEFT JOIN Clientes c ON p.id_cliente = c.id_cliente
            LEFT JOIN DetallePedidos dp ON p.id_pedido = dp.id_pedido
            LEFT JOIN productos pr ON dp.id_producto = pr.id_producto
            LEFT JOIN Ventas v ON p.id_pedido = v.id_pedido";
    $result = $conn->query($sql);
    $pedidos = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $pedidos[] = $row;
        }
    }
    $conn->close();
    return $pedidos;
}

$pedidos = getPedidos();
$clientes = getClientes();
$productos = getProductosDisponibles();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Pedidos</title>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #34495e;
            --accent-color: #3498db;
            --light-color: #ecf0f1;
            --danger-color: #e74c3c;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --border-radius: 4px;
            --box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color:rgb(120, 225, 239);
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--light-color);
        }
        
        .search-bar {
            display: flex;
            margin-bottom: 20px;
            gap: 10px;
        }
        
        .search-bar input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
        }
        
        .search-bar button {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-search {
            background-color: var(--accent-color);
            color: white;
        }
        
        .btn-clear {
            background-color: var(--light-color);
            color: var(--secondary-color);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: var(--primary-color);
            color: white;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .action-btns {
            display: flex;
            gap: 5px;
        }
        
        .btn-edit {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-delete {
            background-color: var(--danger-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .footer-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        
        .btn-main {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-add {
            background-color: var(--success-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-refresh {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        hr {
            border: 0;
            height: 1px;
            background-color: #ddd;
            margin: 20px 0;
        }
        
        .no-data {
            text-align: center;
            padding: 20px;
            color: #777;
            font-style: italic;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 80%;
            max-width: 600px;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        
        .modal-title {
            font-size: 1.5rem;
            color: var(--primary-color);
        }
        
        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
        }
        
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-primary {
            background-color: var(--accent-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: var(--light-color);
            color: var(--secondary-color);
        }
        
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .badge-pendiente {
            background-color: var(--warning-color);
            color: white;
        }
        
        .badge-preparacion {
            background-color: #f1c40f;
            color: white;
        }
        
        .badge-completado {
            background-color: var(--success-color);
            color: white;
        }
        
        .badge-cancelado {
            background-color: var(--danger-color);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>GESTIÓN DE PEDIDOS</h1>
        
        <div class="search-bar">
            <input type="text" id="search-input" placeholder="Buscar pedido...">
            <button class="btn-search" id="btn-search">Buscar</button>
            <button class="btn-clear" id="btn-clear">Limpiar</button>
        </div>
        
        <hr>
        
        <table id="pedidos-table">
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Cliente</th>
                    <th>Fecha Pedido</th>
                    <th>Fecha Entrega</th>
                    <th>Estado</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Total</th>
                    <th>Método Pago</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($pedidos) > 0): ?>
                    <?php foreach ($pedidos as $pedido): ?>
                        <tr data-id="<?= $pedido['id_pedido'] ?>" data-cliente-id="<?= $pedido['id_cliente'] ?>">
                            <td><?= htmlspecialchars($pedido['id_pedido']) ?></td>
                            <td><?= htmlspecialchars($pedido['nombre_cliente']) ?></td>
                            <td><?= htmlspecialchars($pedido['fecha_pedido']) ?></td>
                            <td><?= htmlspecialchars($pedido['fecha_entrega']) ?></td>
                            <td>
                                <span class="badge badge-<?= strtolower($pedido['estado']) ?>">
                                    <?= htmlspecialchars($pedido['estado']) ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($pedido['producto']) ?></td>
                            <td><?= htmlspecialchars($pedido['cantidad']) ?></td>
                            <td>$<?= number_format($pedido['precio_unitario'], 2) ?></td>
                            <td>$<?= number_format($pedido['precio_unitario'] * $pedido['cantidad'], 2) ?></td>
                            <td><?= htmlspecialchars($pedido['metodo_pago'] ?? 'N/A') ?></td>
                            <td class="action-btns">
                                <button class="btn-edit" onclick="editarPedido(<?= $pedido['id_pedido'] ?>)">Editar</button>
                                <button class="btn-delete" onclick="confirmarEliminar(<?= $pedido['id_pedido'] ?>)">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11" class="no-data">No se encontraron pedidos registrados</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div class="footer-actions">
            <button class="btn-main" onclick="window.location.href='principal.php'">Regresar al Principal</button>
            <div>
                <button class="btn-add" id="btn-nuevo-pedido">Registrar Pedido</button>
                <button class="btn-refresh" onclick="actualizarTabla()">Actualizar Lista</button>
            </div>
        </div>
    </div>

    <!-- Modal para formulario -->
    <div id="pedido-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="modal-title">Nuevo Pedido</h2>
                <span class="close">&times;</span>
            </div>
            <form id="pedido-form">
                <input type="hidden" id="id_pedido" name="id_pedido" value="">
                <input type="hidden" name="action" id="form-action" value="crear">
                
                <div class="form-group">
                    <label for="id_cliente" class="form-label">Cliente</label>
                    <select id="id_cliente" name="id_cliente" class="form-control" required>
                        <option value="">Seleccione un cliente</option>
                        <?php foreach ($clientes as $cliente): ?>
                            <option value="<?= $cliente['id_cliente'] ?>"><?= htmlspecialchars($cliente['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="fecha_pedido" class="form-label">Fecha de Pedido</label>
                    <input type="datetime-local" id="fecha_pedido" name="fecha_pedido" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="fecha_entrega" class="form-label">Fecha de Entrega</label>
                    <input type="date" id="fecha_entrega" name="fecha_entrega" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="estado" class="form-label">Estado</label>
                    <select id="estado" name="estado" class="form-control" required>
                        <option value="Pendiente">Pendiente</option>
                        <option value="Preparacion">En preparación</option>
                        <option value="Completado">Completado</option>
                        <option value="Cancelado">Cancelado</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="metodo_pago" class="form-label">Método de Pago</label>
                    <select id="metodo_pago" name="metodo_pago" class="form-control">
                        <option value="Efectivo">Efectivo</option>
                        <option value="Tarjeta">Tarjeta</option>
                        <option value="Transferencia">Transferencia</option>
                        <option value="Otro">Otro</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="id_producto" class="form-label">Producto</label>
                    <select id="id_producto" name="id_producto" class="form-control" required>
                        <option value="">Seleccione un producto</option>
                        <?php foreach ($productos as $producto): ?>
                            <option value="<?= $producto['id_producto'] ?>" data-stock="<?= $producto['stock'] ?>">
                                <?= htmlspecialchars($producto['nombre_producto']) ?> (Disponible: <?= $producto['stock'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="cantidad" class="form-label">Cantidad</label>
                    <input type="number" id="cantidad" name="cantidad" class="form-control" min="1" required>
                    <small id="stock-message" style="color: #e74c3c; display: none;"></small>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="btn-cancelar">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Variables globales
        const modal = document.getElementById('pedido-modal');
        const span = document.getElementsByClassName('close')[0];
        const form = document.getElementById('pedido-form');
        const btnNuevo = document.getElementById('btn-nuevo-pedido');
        const btnCancelar = document.getElementById('btn-cancelar');
        const productoSelect = document.getElementById('id_producto');
        const cantidadInput = document.getElementById('cantidad');
        const stockMessage = document.getElementById('stock-message');
        
        // Validar cantidad contra stock disponible
        productoSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const stockDisponible = selectedOption.dataset.stock || 0;
            
            cantidadInput.max = stockDisponible;
            
            if (cantidadInput.value > stockDisponible) {
                stockMessage.textContent = `Stock insuficiente. Máximo disponible: ${stockDisponible}`;
                stockMessage.style.display = 'block';
            } else {
                stockMessage.style.display = 'none';
            }
        });
        
        cantidadInput.addEventListener('input', function() {
            const selectedOption = productoSelect.options[productoSelect.selectedIndex];
            const stockDisponible = selectedOption.dataset.stock || 0;
            
            if (this.value > stockDisponible) {
                stockMessage.textContent = `Stock insuficiente. Máximo disponible: ${stockDisponible}`;
                stockMessage.style.display = 'block';
            } else {
                stockMessage.style.display = 'none';
            }
        });
        
        // Abrir modal para nuevo pedido
        btnNuevo.onclick = function() {
            document.getElementById('modal-title').textContent = 'Nuevo Pedido';
            document.getElementById('form-action').value = 'crear';
            document.getElementById('id_pedido').value = '';
            form.reset();
            
            // Establecer fecha actual por defecto
            const today = new Date();
            document.getElementById('fecha_pedido').value = today.toISOString().slice(0, 16);
            document.getElementById('fecha_entrega').value = today.toISOString().slice(0, 10);
            
            modal.style.display = 'block';
        }
        
        // Cerrar modal al hacer clic en la X
        span.onclick = function() {
            modal.style.display = 'none';
        }
        
        // Cerrar modal al hacer clic fuera del contenido
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
        
        // Cancelar formulario
        btnCancelar.onclick = function() {
            modal.style.display = 'none';
        }
        
        // Editar pedido
        function editarPedido(id) {
            const row = document.querySelector(`tr[data-id="${id}"]`);
            
            document.getElementById('modal-title').textContent = 'Editar Pedido';
            document.getElementById('form-action').value = 'editar';
            document.getElementById('id_pedido').value = id;
            
            // Formatear fecha para el input datetime-local
            const fechaPedido = new Date(row.cells[2].textContent);
            const offset = fechaPedido.getTimezoneOffset() * 60000;
            const localISOTime = new Date(fechaPedido - offset).toISOString().slice(0, 16);
            
            document.getElementById('fecha_pedido').value = localISOTime;
            document.getElementById('fecha_entrega').value = row.cells[3].textContent;
            document.getElementById('estado').value = row.cells[4].textContent.trim();
            
            // Seleccionar método de pago correcto
            const metodoPago = row.cells[9].textContent.trim();
            document.getElementById('metodo_pago').value = metodoPago !== 'N/A' ? metodoPago : 'Efectivo';
            
            // Seleccionar producto correcto
            const productoId = row.getAttribute('data-producto-id');
            document.getElementById('id_producto').value = productoId;
            
            // Actualizar cantidad
            document.getElementById('cantidad').value = row.cells[6].textContent;
            
            // Seleccionar cliente correcto
            const clienteId = row.getAttribute('data-cliente-id');
            document.getElementById('id_cliente').value = clienteId;
            
            modal.style.display = 'block';
        }
        
        // Confirmar eliminación
        function confirmarEliminar(id) {
            if (confirm('¿Está seguro de eliminar este pedido?')) {
                eliminarPedido(id);
            }
        }
        
        // Eliminar pedido
        function eliminarPedido(id) {
            const formData = new FormData();
            formData.append('action', 'eliminar');
            formData.append('id_pedido', id);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Pedido eliminado correctamente');
                    actualizarTabla();
                } else {
                    alert(data.message || 'Error al eliminar el pedido');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al eliminar el pedido');
            });
        }
        
        // Enviar formulario
        form.onsubmit = function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            const action = formData.get('action');
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(`Pedido ${action === 'crear' ? 'creado' : 'actualizado'} correctamente`);
                    modal.style.display = 'none';
                    actualizarTabla();
                } else {
                    alert(data.message || 'Error al guardar el pedido');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error al guardar el pedido');
            });
        }
        
        // Actualizar tabla
        function actualizarTabla() {
            location.reload();
        }
        
        // Buscar pedidos
        document.getElementById('btn-search').addEventListener('click', function() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const rows = document.querySelectorAll('#pedidos-table tbody tr');
            
            rows.forEach(row => {
                if (row.querySelector('td.no-data')) return;
                
                let found = false;
                const cells = row.querySelectorAll('td');
                
                for (let i = 0; i < cells.length - 1; i++) {
                    if (cells[i].textContent.toLowerCase().includes(searchTerm)) {
                        found = true;
                        break;
                    }
                }
                
                row.style.display = found ? '' : 'none';
            });
        });
        
        // Limpiar búsqueda
        document.getElementById('btn-clear').addEventListener('click', function() {
            document.getElementById('search-input').value = '';
            const rows = document.querySelectorAll('#pedidos-table tbody tr');
            rows.forEach(row => row.style.display = '');
        });
    </script>
</body>
</html>