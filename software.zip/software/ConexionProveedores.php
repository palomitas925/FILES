<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$servername = "localhost";
$username = "tu_usuario";
$password = "tu_contraseña";
$dbname = "nombre_base_datos";

// Conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Error de conexión: ' . $conn->connect_error]));
}

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

switch ($action) {
    case 'getAll':
        $sql = "SELECT * FROM proveedores";
        $result = $conn->query($sql);
        
        $providers = [];
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $providers[] = $row;
            }
        }
        
        echo json_encode($providers);
        break;
        
    case 'getOne':
        $id = $_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM proveedores WHERE id_proveedor = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            echo json_encode($result->fetch_assoc());
        } else {
            echo json_encode(['success' => false, 'message' => 'Proveedor no encontrado']);
        }
        break;
        
    case 'create':
        $data = json_decode($_POST['data'], true);
        
        $stmt = $conn->prepare("INSERT INTO proveedores (nombre, Producto, Cantidad, telefono, direccion, correo, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssissss", 
            $data['nombre'],
            $data['Producto'],
            $data['Cantidad'],
            $data['telefono'],
            $data['direccion'],
            $data['correo'],
            $data['fecha_registro']
        );
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Proveedor creado correctamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al crear proveedor: ' . $conn->error]);
        }
        break;
        
    case 'update':
        $data = json_decode($_POST['data'], true);
        
        $stmt = $conn->prepare("UPDATE proveedores SET nombre = ?, Producto = ?, Cantidad = ?, telefono = ?, direccion = ?, correo = ?, fecha_registro = ? WHERE id_proveedor = ?");
        $stmt->bind_param("ssissssi", 
            $data['nombre'],
            $data['Producto'],
            $data['Cantidad'],
            $data['telefono'],
            $data['direccion'],
            $data['correo'],
            $data['fecha_registro'],
            $data['id_proveedor']
        );
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Proveedor actualizado correctamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al actualizar proveedor: ' . $conn->error]);
        }
        break;
        
    case 'delete':
        $id = $_POST['id'];
        
        $stmt = $conn->prepare("DELETE FROM proveedores WHERE id_proveedor = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Proveedor eliminado correctamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al eliminar proveedor: ' . $conn->error]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
        break;
}

$conn->close();
?>