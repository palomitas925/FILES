<?php
// conexion.php
$host = 'localhost';
$dbname = 'admin';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $id_proveedor = $_POST['id_proveedor'] ?? null;
    
    if ($action == 'guardar') {
        if (empty($id_proveedor)) {
            // Insertar nuevo proveedor
            $stmt = $conn->prepare("INSERT INTO proveedores (nombre, producto, cantidad, telefono, direccion, correo, fecha_registro) 
                                  VALUES (?, ?, ?, ?, ?, ?, CURDATE())");
        } else {
            // Actualizar proveedor existente
            $stmt = $conn->prepare("UPDATE proveedores SET nombre=?, producto=?, cantidad=?, telefono=?, direccion=?, correo=?
                                  WHERE id_proveedor=?");
        }
        
        $params = [
            $_POST['nombre'],
            $_POST['producto'],
            $_POST['cantidad'],
            $_POST['telefono'],
            $_POST['direccion'],
            $_POST['correo']
        ];
        
        if (!empty($id_proveedor)) $params[] = $id_proveedor;
        
        $stmt->execute($params);
    } elseif ($action == 'eliminar') {
        $stmt = $conn->prepare("DELETE FROM proveedores WHERE id_proveedor=?");
        $stmt->execute([$id_proveedor]);
        
        header("Location: proveedores.php?eliminado=1");
        exit;
    }
    
    header("Location: proveedores.php");
    exit;
}

// Obtener proveedores
$search = $_GET['search'] ?? '';

$query = "SELECT * FROM proveedores WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (nombre LIKE ? OR producto LIKE ? OR correo LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
}

$query .= " ORDER BY fecha_registro DESC";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$proveedores = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Proveedores</title>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --light-color: #ecf0f1;
            --dark-color: #34495e;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color:rgb(111, 200, 232);
            color: #333;
        }
        
        .container {
            width: 95%;
            margin: 20px auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        
        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px;
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 10px;
        }
        
        .search-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .search-group {
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        
        .search-input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            min-width: 250px;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-danger {
            background-color: #e74c3c;
            color: white;
        }
        
        .btn-info {
            background-color: #17a2b8;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: var(--primary-color);
            color: white;
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #f1f1f1;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .action-btn {
            padding: 5px 10px;
            font-size: 14px;
            border-radius: 3px;
        }
        
        .footer-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
        
        .footer-btn {
            padding: 10px 20px;
            font-size: 16px;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .form-group input, 
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        
        .date-info {
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 5px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        
        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }

        @media (max-width: 768px) {
            .search-container {
                justify-content: center;
            }
            
            .search-group {
                flex-direction: column;
                width: 100%;
            }
            
            .search-input {
                width: 100%;
                min-width: auto;
            }
            
            .modal-content {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>DATOS DE LOS PROVEEDORES</h1>
        
        <?php if (isset($_GET['eliminado'])): ?>
        <div class="alert alert-success">
            Proveedor eliminado correctamente.
        </div>
        <?php endif; ?>
        
        <!-- Barra de búsqueda -->
        <div class="search-container">
            <div class="search-group">
                <input type="text" class="search-input" placeholder="Buscar proveedor..." id="searchInput"
                       value="<?= htmlspecialchars($search) ?>">
                
                <button class="btn btn-primary" onclick="searchProveedores()">Buscar</button>
                <button class="btn btn-secondary" onclick="clearSearch()">Limpiar</button>
            </div>
        </div>
        
        <!-- Tabla de proveedores -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Teléfono</th>
                    <th>Dirección</th>
                    <th>Correo</th>
                    <th>Fecha Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($proveedores as $proveedor): ?>
                <tr>
                    <td><?= $proveedor['id_proveedor'] ?></td>
                    <td><?= htmlspecialchars($proveedor['nombre']) ?></td>
                    <td><?= htmlspecialchars($proveedor['producto']) ?></td>
                    <td><?= htmlspecialchars($proveedor['cantidad']) ?></td>
                    <td><?= htmlspecialchars($proveedor['telefono']) ?></td>
                    <td><?= htmlspecialchars($proveedor['direccion']) ?></td>
                    <td><?= htmlspecialchars($proveedor['correo']) ?></td>
                    <td><?= $proveedor['fecha_registro'] ?></td>
                    <td class="action-buttons">
                        <button class="btn btn-primary action-btn" 
                                onclick="openEditModal(
                                    <?= $proveedor['id_proveedor'] ?>,
                                    '<?= addslashes($proveedor['nombre']) ?>',
                                    '<?= addslashes($proveedor['producto']) ?>',
                                    '<?= addslashes($proveedor['cantidad']) ?>',
                                    '<?= addslashes($proveedor['telefono']) ?>',
                                    '<?= addslashes($proveedor['direccion']) ?>',
                                    '<?= addslashes($proveedor['correo']) ?>'
                                )">
                            Editar
                        </button>
                        <form method="POST" style="display: inline-block;">
                            <input type="hidden" name="action" value="eliminar">
                            <input type="hidden" name="id_proveedor" value="<?= $proveedor['id_proveedor'] ?>">
                            <button type="submit" class="btn btn-danger action-btn" onclick="return confirm('¿Está seguro de eliminar este proveedor?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Botones inferiores -->
        <div class="footer-buttons">
            <a href="principal.php" class="btn btn-info footer-btn">Regresar al Principal</a>
            <div>
                <button class="btn btn-primary footer-btn" onclick="openAddModal()">Registrar Proveedor</button>
                <button class="btn btn-secondary footer-btn" onclick="window.location.reload()">Actualizar Lista</button>
            </div>
        </div>
    </div>
    
    <!-- Modal para agregar/editar proveedores -->
    <div id="proveedorModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2 id="modalTitle">Nuevo Proveedor</h2>
            
            <form id="proveedorForm" method="POST">
                <input type="hidden" name="action" id="formAction" value="guardar">
                <input type="hidden" name="id_proveedor" id="id_proveedor" value="">
                
                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" required>
                </div>
                
                <div class="form-group">
                    <label for="producto">Producto:</label>
                    <input type="text" id="producto" name="producto" required>
                </div>
                
                <div class="form-group">
                    <label for="cantidad">Cantidad:</label>
                    <input type="number" id="cantidad" name="cantidad" required>
                </div>
                
                <div class="form-group">
                    <label for="telefono">Teléfono:</label>
                    <input type="tel" id="telefono" name="telefono" required>
                </div>
                
                <div class="form-group">
                    <label for="direccion">Dirección:</label>
                    <textarea id="direccion" name="direccion" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="correo">Correo Electrónico:</label>
                    <input type="email" id="correo" name="correo" required>
                </div>
                
                <div class="date-info">
                    <span id="fechaRegistroText"></span>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-danger" onclick="closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Funciones para manejar los modales
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Nuevo Proveedor';
            document.getElementById('formAction').value = 'guardar';
            document.getElementById('id_proveedor').value = '';
            document.getElementById('fechaRegistroText').textContent = 'Se registrará con la fecha actual';
            document.getElementById('proveedorForm').reset();
            document.getElementById('proveedorModal').style.display = 'block';
        }
        
        function openEditModal(id, nombre, Producto, Cantidad, telefono, direccion, correo) {
            document.getElementById('modalTitle').textContent = 'Editar Proveedor';
            document.getElementById('formAction').value = 'guardar';
            document.getElementById('id_proveedor').value = id;
            document.getElementById('nombre').value = nombre;
            document.getElementById('producto').value = Producto;
            document.getElementById('cantidad').value = Cantidad;
            document.getElementById('telefono').value = telefono;
            document.getElementById('direccion').value = direccion;
            document.getElementById('correo').value = correo;
            document.getElementById('fechaRegistroText').textContent = 'Fecha de registro no modificable';
            
            document.getElementById('proveedorModal').style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('proveedorModal').style.display = 'none';
        }
        
        function searchProveedores() {
            const searchValue = document.getElementById('searchInput').value;
            window.location.href = `?search=${encodeURIComponent(searchValue)}`;
        }
        
        function clearSearch() {
            window.location.href = '?';
        }
        
        // Cerrar modal al hacer clic fuera del contenido
        window.onclick = function(event) {
            const modal = document.getElementById('proveedorModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>