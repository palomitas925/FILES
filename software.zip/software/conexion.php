?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

// Crear conexión
$conexion = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Establecer el charset a utf8
$conexion->set_charset("utf8");
?>