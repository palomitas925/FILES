<?php
// get_data.php
require_once 'conexion.php';

// Configuración de cabeceras y codificación
header('Content-Type: application/json; charset=utf-8');
mb_internal_encoding('UTF-8');

// Validación de parámetros
$action = $_GET['action'] ?? '';
$fechaInicio = $_GET['fecha_inicio'] ?? null;
$fechaFin = $_GET['fecha_fin'] ?? null;
$agrupacion = $_GET['agrupacion'] ?? 'mes';

// Lista de acciones permitidas
$accionesPermitidas = [
    'productos_barras', 'productos_pastel',
    'clientes_barras', 'clientes_pastel',
    'ventas_barras', 'ventas_pastel',
    'pedidos_barras', 'pedidos_pastel'
];

// Validar acción
if (empty($action)) {
    echo json_encode(['error' => 'Parámetro "action" requerido', 'status' => 'error']);
    exit;
}

if (!in_array($action, $accionesPermitidas)) {
    echo json_encode(['error' => 'Acción no permitida', 'status' => 'error']);
    exit;
}

try {
    switch ($action) {
        case 'productos_barras':
            $resultado = getProductosMasVendidos($fechaInicio, $fechaFin, $agrupacion);
            break;
        case 'productos_pastel':
            $resultado = getDistribucionProductos($fechaInicio, $fechaFin);
            break;
        case 'clientes_barras':
            $resultado = getClientesPorPeriodo($fechaInicio, $fechaFin, $agrupacion);
            break;
        case 'clientes_pastel':
            $resultado = getClientesPorTipo($fechaInicio, $fechaFin);
            break;
        case 'ventas_barras':
            $resultado = getVentasPorPeriodo($fechaInicio, $fechaFin, $agrupacion);
            break;
        case 'ventas_pastel':
            $resultado = getMetodosPago($fechaInicio, $fechaFin);
            break;
        case 'pedidos_barras':
            $resultado = getPedidosPorPeriodo($fechaInicio, $fechaFin, $agrupacion);
            break;
        case 'pedidos_pastel':
            $resultado = getEstadosPedidos($fechaInicio, $fechaFin);
            break;
    }
    
    // Verificar si se obtuvo resultado
    if (!isset($resultado)) {
        throw new Exception('No se pudo generar el resultado para la acción solicitada');
    }
    
    echo $resultado;
    
} catch (PDOException $e) {
    echo json_encode([
        'error' => 'Error en la base de datos',
        'detalle' => $e->getMessage(),
        'status' => 'error'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'status' => 'error'
    ]);
}

function getProductosMasVendidos($fechaInicio, $fechaFin, $agrupacion) {
    global $pdo;
    
    $sql = "SELECT p.nombre_producto, SUM(dp.cantidad) as total_vendido 
            FROM DetallePedidos dp
            JOIN Productos p ON dp.id_producto = p.id_producto
            JOIN Pedidos ped ON dp.id_pedido = ped.id_pedido";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "ped.fecha_pedido >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "ped.fecha_pedido <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin . ' 23:59:59';
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY p.nombre_producto ORDER BY total_vendido DESC LIMIT 10";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = $row['nombre_producto'];
        $values[] = (int)$row['total_vendido'];
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}

function getDistribucionProductos($fechaInicio, $fechaFin) {
    global $pdo;
    
    $sql = "SELECT p.nombre_producto, SUM(dp.cantidad) as total_vendido 
            FROM DetallePedidos dp
            JOIN Productos p ON dp.id_producto = p.id_producto
            JOIN Pedidos ped ON dp.id_pedido = ped.id_pedido";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "ped.fecha_pedido >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "ped.fecha_pedido <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin . ' 23:59:59';
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY p.nombre_producto ORDER BY total_vendido DESC LIMIT 6";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = $row['nombre_producto'];
        $values[] = (int)$row['total_vendido'];
    }
    
    if (count($data) > 5) {
        $sqlOtros = str_replace("LIMIT 6", "", $sql);
        $sqlOtros = "SELECT SUM(total_vendido) as total FROM (" . $sqlOtros . " LIMIT 100 OFFSET 5) as subquery";
        
        $stmtOtros = $pdo->prepare($sqlOtros);
        $stmtOtros->execute($params);
        $otros = $stmtOtros->fetch(PDO::FETCH_ASSOC);
        
        if ($otros['total']) {
            $labels = array_slice($labels, 0, 5);
            $values = array_slice($values, 0, 5);
            
            $labels[] = 'Otros';
            $values[] = (int)$otros['total'];
        }
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}

function getClientesPorPeriodo($fechaInicio, $fechaFin, $agrupacion) {
    global $pdo;
    
    switch ($agrupacion) {
        case 'dia':
            $format = "DATE_FORMAT(fecha_registro, '%Y-%m-%d')";
            break;
        case 'mes':
            $format = "DATE_FORMAT(fecha_registro, '%Y-%m')";
            break;
        case 'anio':
            $format = "DATE_FORMAT(fecha_registro, '%Y')";
            break;
        default:
            $format = "DATE_FORMAT(fecha_registro, '%Y-%m')";
    }
    
    $sql = "SELECT $format as periodo, COUNT(*) as total 
            FROM Clientes";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "fecha_registro >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "fecha_registro <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin;
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY periodo ORDER BY periodo";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = $row['periodo'];
        $values[] = (int)$row['total'];
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}

function getClientesPorTipo($fechaInicio, $fechaFin) {
    global $pdo;
    
    $sql = "SELECT 
                CASE 
                    WHEN correo LIKE '%gmail%' THEN 'Gmail'
                    WHEN correo LIKE '%hotmail%' OR correo LIKE '%outlook%' THEN 'Microsoft'
                    WHEN correo LIKE '%yahoo%' THEN 'Yahoo'
                    WHEN correo IS NULL OR correo = '' THEN 'Sin correo'
                    ELSE 'Otros'
                END as tipo_correo,
                COUNT(*) as total
            FROM Clientes";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "fecha_registro >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "fecha_registro <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin;
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY tipo_correo ORDER BY total DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = $row['tipo_correo'];
        $values[] = (int)$row['total'];
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}

function getVentasPorPeriodo($fechaInicio, $fechaFin, $agrupacion) {
    global $pdo;
    
    switch ($agrupacion) {
        case 'dia':
            $format = "DATE_FORMAT(fecha_venta, '%Y-%m-%d')";
            break;
        case 'mes':
            $format = "DATE_FORMAT(fecha_venta, '%Y-%m')";
            break;
        case 'anio':
            $format = "DATE_FORMAT(fecha_venta, '%Y')";
            break;
        default:
            $format = "DATE_FORMAT(fecha_venta, '%Y-%m')";
    }
    
    $sql = "SELECT $format as periodo, SUM(monto_total) as total 
            FROM Ventas";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "fecha_venta >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "fecha_venta <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin . ' 23:59:59';
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY periodo ORDER BY periodo";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = $row['periodo'];
        $values[] = (float)$row['total'];
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}

function getMetodosPago($fechaInicio, $fechaFin) {
    global $pdo;
    
    $sql = "SELECT metodo_pago, COUNT(*) as total, SUM(monto_total) as monto_total
            FROM Ventas";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "fecha_venta >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "fecha_venta <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin . ' 23:59:59';
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY metodo_pago ORDER BY total DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = ucfirst($row['metodo_pago']);
        $values[] = (float)$row['monto_total'];
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}

function getPedidosPorPeriodo($fechaInicio, $fechaFin, $agrupacion) {
    global $pdo;
    
    switch ($agrupacion) {
        case 'dia':
            $format = "DATE_FORMAT(fecha_pedido, '%Y-%m-%d')";
            break;
        case 'mes':
            $format = "DATE_FORMAT(fecha_pedido, '%Y-%m')";
            break;
        case 'anio':
            $format = "DATE_FORMAT(fecha_pedido, '%Y')";
            break;
        default:
            $format = "DATE_FORMAT(fecha_pedido, '%Y-%m')";
    }
    
    $sql = "SELECT $format as periodo, COUNT(*) as total 
            FROM Pedidos";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "fecha_pedido >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "fecha_pedido <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin . ' 23:59:59';
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY periodo ORDER BY periodo";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = $row['periodo'];
        $values[] = (int)$row['total'];
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}

function getEstadosPedidos($fechaInicio, $fechaFin) {
    global $pdo;
    
    $sql = "SELECT estado, COUNT(*) as total 
            FROM Pedidos";
    
    $where = [];
    $params = [];
    
    if ($fechaInicio) {
        $where[] = "fecha_pedido >= :fecha_inicio";
        $params[':fecha_inicio'] = $fechaInicio;
    }
    
    if ($fechaFin) {
        $where[] = "fecha_pedido <= :fecha_fin";
        $params[':fecha_fin'] = $fechaFin . ' 23:59:59';
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " GROUP BY estado ORDER BY total DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $values = [];
    
    foreach ($data as $row) {
        $labels[] = ucfirst($row['estado']);
        $values[] = (int)$row['total'];
    }
    
    return json_encode([
        'labels' => $labels,
        'values' => $values,
        'status' => 'success'
    ]);
}
?>