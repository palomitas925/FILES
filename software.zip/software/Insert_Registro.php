<?php
// Configuración de la base de datos 
define('DB_HOST', 'localhost');
define('DB_NAME', 'admin');
define('DB_USER', 'root');
define('DB_PASS', '');

// Establecer conexión
try {
    $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8";
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    header("Location: registrar_producto.php?status=error&message=" . urlencode("Error de conexión: " . $e->getMessage()));
    exit();
}

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recoger y sanitizar datos
    $nombre = filter_input(INPUT_POST, 'nombre_producto', FILTER_SANITIZE_STRING);
    $descripcion = filter_input(INPUT_POST, 'descripcion', FILTER_SANITIZE_STRING);
    $variedad = filter_input(INPUT_POST, 'variedad', FILTER_SANITIZE_STRING);
    $stock = filter_input(INPUT_POST, 'stock', FILTER_VALIDATE_INT);
    $precio = filter_input(INPUT_POST, 'precio_unitario', FILTER_VALIDATE_FLOAT);
    $estado = filter_input(INPUT_POST, 'estado', FILTER_SANITIZE_STRING);

    // Validar datos
    if (empty($nombre) || $stock === false || $precio === false || $precio <= 0 || $stock < 0) {
        header("Location: registrar_producto.php?status=error&message=" . urlencode("Datos inválidos o incompletos"));
        exit();
    }

    // Validar estado
    $estadosPermitidos = ['activo', 'inactivo', 'agotado'];
    if (!in_array($estado, $estadosPermitidos)) {
        $estado = 'activo'; // Valor por defecto
    }

    // Preparar y ejecutar la consulta
    try {
        $sql = "INSERT INTO Productos (nombre_producto, descripcion, variedad, stock, precio_unitario, estado) 
                VALUES (:nombre, :descripcion, :variedad, :stock, :precio, :estado)";
        
        $stmt = $pdo->prepare($sql);
        
        $stmt->execute([
            ':nombre' => $nombre,
            ':descripcion' => $descripcion,
            ':variedad' => $variedad,
            ':stock' => $stock,
            ':precio' => $precio,
            ':estado' => $estado
        ]);
        
        // Redirigir con éxito
        header("Location: registrar_producto.php?status=success");
        exit();
        
    } catch (PDOException $e) {
        error_log("Error al insertar producto: " . $e->getMessage());
        header("Location: registrar_producto.php?status=error&message=" . urlencode("Error al guardar en la base de datos"));
        exit();
    }
} else {
    // Si no es POST, redirigir
    header("Location: registrar_producto.php");
    exit();
}
?>