<?php
// Conexión a la base de datos 
include 'conexion.php';

// Variables para filtrado
$filtro_nombre = isset($_GET['nombre']) ? $_GET['nombre'] : '';
$filtro_estado = isset($_GET['estado']) ? $_GET['estado'] : '';

// Procesar actualización de producto
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['actualizar_producto'])) {
    $id_producto = $_POST['id_producto'];
    $nombre = $_POST['nombre_producto'];
    $descripcion = $_POST['descripcion'];
    $variedad = $_POST['variedad'];
    $stock = $_POST['stock'];
    $precio = $_POST['precio_unitario'];

    // Actualizar en la base de datos
    $update_query = "UPDATE Productos SET
                    nombre_producto = ?,
                    descripcion = ?,
                    variedad = ?,
                    stock = ?,
                    precio_unitario = ?
                    WHERE id_producto = ?";

    $stmt = $conexion->prepare($update_query);
    $stmt->bind_param("sssdsi", $nombre, $descripcion, $variedad, $stock, $precio, $id_producto);

    if ($stmt->execute()) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?success=Producto actualizado correctamente");
        exit();
    } else {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=Error al actualizar el producto");
        exit();
    }
}

// Procesar eliminación de producto
if (isset($_GET['eliminar'])) {
    $id_producto = $_GET['eliminar'];

    $delete_query = "DELETE FROM Productos WHERE id_producto = ?";
    $stmt = $conexion->prepare($delete_query);
    $stmt->bind_param("i", $id_producto);

    if ($stmt->execute()) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?success=Producto eliminado correctamente");
        exit();
    } else {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=Error al eliminar el producto");
        exit();
    }
}

// Consulta base para obtener los productos
$query = "SELECT id_producto, nombre_producto, descripcion, variedad, 
          stock, precio_unitario, estado
          FROM Productos
          WHERE 1=1";

// Añadir condiciones de filtrado
if (!empty($filtro_nombre)) {
    $query .= " AND nombre_producto LIKE '%$filtro_nombre%'";
}
if (!empty($filtro_estado)) {
    if ($filtro_estado == 'disponible') {
        $query .= " AND stock >= 20";
    } elseif ($filtro_estado == 'bajo_stock') {
        $query .= " AND stock < 20 AND stock > 0";
    } elseif ($filtro_estado == 'agotado') {
        $query .= " AND stock <= 0";
    }
}

$resultado = $conexion->query($query);

// Obtener datos del producto a editar si se ha solicitado
$producto_a_editar = null;
if (isset($_GET['editar'])) {
    $id_producto = $_GET['editar'];
    $query_editar = "SELECT id_producto, nombre_producto, descripcion, variedad, 
                     stock, precio_unitario
                     FROM Productos
                     WHERE id_producto = $id_producto";
    $result_editar = $conexion->query($query_editar);
    if ($result_editar->num_rows > 0) {
        $producto_a_editar = $result_editar->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Inventario Florícola</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 15px;
            background: linear-gradient(135deg, rgb(88, 197, 222) 0%, rgb(69, 242, 233) 50%, #7db9e8 100%);
            color: #333;
            min-height: 100vh;
            background-attachment: fixed;
        }

        .main-container {
            max-width: 100%;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            padding: 20px;
            overflow-x: auto;
        }

        h1 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
            font-size: 1.5rem;
        }

        .search-container {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #eee;
            margin-bottom: 15px;
        }

        .search-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-group {
            flex: 1;
        }

        .search-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
            font-size: 0.9rem;
        }

        .search-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .filter-group {
            margin-bottom: 15px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
            font-size: 0.9rem;
        }

        .filter-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .filter-button {
            padding: 8px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s;
        }

        .filter-button:hover {
            background-color: #45a049;
            transform: translateY(-2px);
        }

        .table-container {
            width: 100%;
            overflow-x: auto;
        }

        .products-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            font-size: 0.9rem;
        }

        .products-table th,
        .products-table td {
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            white-space: nowrap;
        }

        .products-table th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #444;
            position: sticky;
            top: 0;
        }

        .products-table tr:hover {
            background-color: #f5f5f5;
        }

        .status-available {
            color: #27ae60;
            font-weight: bold;
        }

        .status-low {
            color: #f39c12;
            font-weight: bold;
        }

        .status-out {
            color: #e74c3c;
            font-weight: bold;
        }

        /* Botones de acción */
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .edit-button,
        .delete-button {
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.8rem;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .edit-button {
            background-color: #2196F3;
            color: white;
        }

        .delete-button {
            background-color: #f44336;
            color: white;
        }

        .edit-button:hover {
            background-color: #0b7dda;
            transform: translateY(-1px);
        }

        .delete-button:hover {
            background-color: #d32f2f;
            transform: translateY(-1px);
        }

        /* Botones principales */
        .button-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .action-button,
        .back-button {
            padding: 10px 15px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s;
            min-width: 150px;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            flex: 1 1 auto;
        }

        .action-button:hover,
        .back-button:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }

        /* Mensajes */
        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            text-align: center;
            font-size: 0.9rem;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Modal de edición */
        .edit-form-container {
            display:
                <?php echo $producto_a_editar ? 'flex' : 'none'; ?>
            ;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 15px;
        }

        .edit-form-box {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            max-height: 90vh;
            overflow-y: auto;
        }

        .edit-form {
            display: grid;
            gap: 12px;
        }

        .form-group {
            margin-bottom: 12px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            font-size: 0.9rem;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .form-group textarea {
            min-height: 80px;
            resize: vertical;
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 15px;
        }

        .save-button,
        .cancel-button {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.2s;
        }

        .save-button {
            background-color: #4CAF50;
            color: white;
        }

        .cancel-button {
            background-color: #f44336;
            color: white;
        }

        .save-button:hover {
            background-color: #3d8b40;
        }

        .cancel-button:hover {
            background-color: #d32f2f;
        }

        /* Modal de confirmación */
        .confirm-dialog {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1001;
            justify-content: center;
            align-items: center;
            padding: 15px;
        }

        .confirm-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }

        .confirm-buttons {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .confirm-button {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.2s;
            flex: 1;
        }

        .confirm-yes {
            background-color: #f44336;
            color: white;
        }

        .confirm-no {
            background-color: #757575;
            color: white;
        }

        .confirm-yes:hover {
            background-color: #d32f2f;
        }

        .confirm-no:hover {
            background-color: #616161;
        }

        /* Media queries para pantallas más grandes */
        @media (min-width: 768px) {
            .main-container {
                max-width: 95%;
                padding: 25px;
            }

            h1 {
                font-size: 2rem;
                margin-bottom: 25px;
            }

            .search-form {
                flex-direction: row;
            }

            .products-table {
                font-size: 1rem;
            }

            .products-table th,
            .products-table td {
                padding: 12px 15px;
            }

            .edit-button,
            .delete-button {
                padding: 6px 12px;
                font-size: 0.9rem;
            }

            .action-button,
            .back-button {
                padding: 12px 20px;
                font-size: 1rem;
                min-width: 200px;
            }
        }

        @media (min-width: 992px) {
            .main-container {
                max-width: 1200px;
            }
        }
     </style>
</head>

<body>
    <div class="main-container">
        <h1>INVENTARIO DE PRODUCTOS FLORÍCOLAS</h1>

        <?php
        if (isset($_GET['success'])) {
            echo '<div class="message success">' . htmlspecialchars($_GET['success']) . '</div>';
        }
        if (isset($_GET['error'])) {
            echo '<div class="message error">' . htmlspecialchars($_GET['error']) . '</div>';
        }
        ?>

        <!-- Contenedor de búsqueda arriba de la tabla -->
        <div class="search-container">
            <form method="GET" action="" class="search-form">
                <div class="search-group">
                    <label for="nombre">Buscar producto:</label>
                    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($filtro_nombre); ?>"
                        placeholder="Ingrese nombre del producto">
                </div>

                <div class="filter-group" style="min-width: 200px;">
                    <label for="estado">Filtrar por estado:</label>
                    <select id="estado" name="estado">
                        <option value="">Todos</option>
                        <option value="disponible" <?php echo ($filtro_estado == 'disponible') ? 'selected' : ''; ?>>
                            Disponible</option>
                        <option value="bajo_stock" <?php echo ($filtro_estado == 'bajo_stock') ? 'selected' : ''; ?>>
                            Bajo Stock</option>
                        <option value="agotado" <?php echo ($filtro_estado == 'agotado') ? 'selected' : ''; ?>>
                            Agotado</option>
                    </select>
                </div>

                <button type="submit" class="filter-button">Buscar</button>
            </form>
        </div>

        <!-- Contenedor de tabla -->
        <div class="table-container">
            <table class="products-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Variedad</th>
                        <th>Stock</th>
                        <th>Precio Unitario</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($resultado->num_rows > 0) {
                        while ($producto = $resultado->fetch_assoc()) {
                            $estado_clase = '';
                            $estado_texto = '';

                            if ($producto['stock'] <= 0) {
                                $estado_clase = 'status-out';
                                $estado_texto = 'Agotado';
                            } elseif ($producto['stock'] < 20) {
                                $estado_clase = 'status-low';
                                $estado_texto = 'Bajo Stock';
                            } else {
                                $estado_clase = 'status-available';
                                $estado_texto = 'Disponible';
                            }

                            echo "<tr>
                                    <td>{$producto['id_producto']}</td>
                                    <td>{$producto['nombre_producto']}</td>
                                    <td>" . substr($producto['descripcion'], 0, 50) . "...</td>
                                    <td>{$producto['variedad']}</td>
                                    <td>{$producto['stock']}</td>
                                    <td>$" . number_format($producto['precio_unitario'], 2) . "</td>
                                    <td class='$estado_clase'>$estado_texto</td>
                                    <td>
                                        <div class='action-buttons'>
                                            <a href='?editar={$producto['id_producto']}' class='edit-button'>Editar</a>
                                            <button onclick='confirmDelete({$producto['id_producto']})' class='delete-button'>Eliminar</button>
                                        </div>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No se encontraron productos con los filtros aplicados</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Botones de acción -->
        <div class="button-container">
            <a href="registrar_producto.php" class="action-button">Registrar Productos</a>
            <a href="?" class="action-button">Actualizar Inventario</a>
            <a href="principal.php" class="back-button">Regresar al Principal</a>
        </div>
    </div>

    <!-- Diálogo de confirmación para eliminar -->
    <div id="confirmDialog" class="confirm-dialog">
        <div class="confirm-content">
            <h3>¿Está seguro que desea eliminar este producto?</h3>
            <p>Esta acción no se puede deshacer.</p>
            <div class="confirm-buttons">
                <button id="confirmYes" class="confirm-button confirm-yes">Sí, eliminar</button>
                <button id="confirmNo" class="confirm-button confirm-no">Cancelar</button>
            </div>
        </div>
    </div>

    <!-- Formulario de edición (modal) -->
    <?php if ($producto_a_editar): ?>
        <div class="edit-form-container">
            <div class="edit-form-box">
                <h2>Editar Producto</h2>
                <form method="POST" action="" class="edit-form">
                    <input type="hidden" name="id_producto" value="<?php echo $producto_a_editar['id_producto']; ?>">

                    <div class="form-group">
                        <label for="nombre_producto">Nombre del Producto:</label>
                        <input type="text" id="nombre_producto" name="nombre_producto"
                            value="<?php echo htmlspecialchars($producto_a_editar['nombre_producto']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="descripcion">Descripción:</label>
                        <textarea id="descripcion" name="descripcion"
                            required><?php echo htmlspecialchars($producto_a_editar['descripcion']); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="variedad">Variedad:</label>
                        <input type="text" id="variedad" name="variedad"
                            value="<?php echo htmlspecialchars($producto_a_editar['variedad']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="stock">Stock:</label>
                        <input type="number" id="stock" name="stock"
                            value="<?php echo htmlspecialchars($producto_a_editar['stock']); ?>" min="0" required>
                    </div>

                    <div class="form-group">
                        <label for="precio_unitario">Precio Unitario:</label>
                        <input type="number" id="precio_unitario" name="precio_unitario" step="0.01"
                            value="<?php echo htmlspecialchars($producto_a_editar['precio_unitario']); ?>" min="0" required>
                    </div>

                    <div class="form-actions">
                        <button type="button" class="cancel-button" onclick="window.location.href='?'">Cancelar</button>
                        <button type="submit" name="actualizar_producto" class="save-button">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <script>
        // Función para mostrar el diálogo de confirmación
        function confirmDelete(id) {
            const dialog = document.getElementById('confirmDialog');
            const confirmYes = document.getElementById('confirmYes');
            const confirmNo = document.getElementById('confirmNo');

            dialog.style.display = 'flex';

            confirmYes.onclick = function () {
                window.location.href = '?eliminar=' + id;
            };

            confirmNo.onclick = function () {
                dialog.style.display = 'none';
            };
        }

        // Cerrar diálogo al hacer clic fuera del contenido
        document.getElementById('confirmDialog').addEventListener('click', function (e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    </script>
</body>

</html>
<?php
$conexion->close();
?>