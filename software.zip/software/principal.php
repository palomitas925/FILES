<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.html");
    exit();
}

$usuario_nombre = $_SESSION['usuario'];
$tipo_usuario = isset($_SESSION['rol_usuario']) ? $_SESSION['rol_usuario'] : "Invitado";
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #007bff;
            --hover-color: #0056b3;
            --danger-color: #ff4d4d;
            --danger-hover: #e04343;
            --night-color: #2c3e50;
            --clock-color: #4CAF50;
            --clock-hover: #3e8e41;
            --text-light: #fff;
            --text-dark: #333;
            --bg-dark: #333;
            --bg-light: #fff;
            --card-bg: rgba(255, 255, 255, 0.95);
            --current-bg: #ffffff;
            --current-text: #333333;
            --current-slogan-bg: #ffffff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: var(--current-bg);
            color: var(--current-text);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            transition: background-color 0.3s, color 0.3s;
        }

        body.night-mode {
            --current-bg: rgb(0, 0, 0);
            --current-text: #e0e0e0;
            --current-slogan-bg: rgb(0, 0, 0);
            --card-bg: rgba(0, 0, 0, 0.9);
            --bg-dark: #1a1a1a;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: var(--bg-dark);
            color: var(--text-light);
            padding: 12px 20px;
            flex-wrap: wrap;
            box-shadow: 0 2px 10px rgb(0, 0, 0);
            z-index: 10;
        }

        .navbar-actions {
            display: flex;
            gap: 10px;
        }

        .navbar .usuario-info {
            font-size: 16px;
            margin: 5px 0;
        }

        .navbar .cerrar-sesion {
            background: var(--danger-color);
            border: none;
            padding: 8px 16px;
            color: var(--text-light);
            font-weight: bold;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .navbar .modo-nocturno {
            background: var(--night-color);
            border: none;
            padding: 8px 16px;
            color: var(--text-light);
            font-weight: bold;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .navbar .clock {
            background: var(--clock-color);
            border: none;
            padding: 8px 16px;
            color: var(--text-light);
            font-weight: bold;
            border-radius: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
            font-family: 'Courier New', monospace;
        }

        .navbar .cerrar-sesion:hover {
            background: var(--danger-hover);
        }

        .navbar .modo-nocturno:hover {
            background: #1a2a3a;
        }

        .main-content {
            display: flex;
            flex: 1;
        }

        .slogan-container {
            flex: 0 0 40%;
            background-color: var(--current-slogan-bg);
            min-height: calc(100vh - 60px);
            position: relative;
            overflow: hidden;
            transition: background-color 0.3s;
        }

        .slogan-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: left center;
            transition: opacity 0.5s ease-in-out;
        }

        .slogan-day {
            background-image: url('SLOGAN.png');
            opacity: 1;
            z-index: 1;
        }

        .slogan-night {
            background-image: url('slogannoche.jpg');
            opacity: 0;
            z-index: 2;
        }

        body.night-mode .slogan-day {
            opacity: 0;
        }

        body.night-mode .slogan-night {
            opacity: 1;
        }

        .menu-container {
            flex: 1;
            padding: 40px 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .botones-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            width: 100%;
            max-width: 800px;
        }

        .boton {
            border: 2px solid var(--primary-color);
            background: var(--card-bg);
            color: var(--current-text);
            font-weight: bold;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s;
            padding: 20px;
            height: 70px;
            text-align: center;
            border-radius: 10px;
            font-size: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .boton:hover {
            background: var(--primary-color);
            color: var(--text-light);
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .boton i {
            font-size: 28px;
        }

        @media (max-width: 1200px) {
            .slogan-container {
                flex: 0 0 35%;
            }

            .boton {
                height: 110px;
                padding: 18px;
            }
        }

        @media (max-width: 992px) {
            .slogan-container {
                flex: 0 0 30%;
            }

            .botones-container {
                grid-template-columns: repeat(2, 1fr);
            }

            .boton {
                height: 100px;
                font-size: 15px;
            }

            .boton i {
                font-size: 24px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }

            .slogan-container {
                flex: 0 0 200px;
                width: 100%;
                background-size: cover;
                background-position: center;
                min-height: auto;
            }

            .menu-container {
                padding: 30px 20px;
            }

            .navbar {
                flex-direction: column;
                align-items: flex-start;
                padding: 15px;
            }

            .navbar-actions {
                width: 100%;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-top: 10px;
            }

            .navbar .cerrar-sesion,
            .navbar .modo-nocturno,
            .navbar .clock {
                width: 100%;
                justify-content: center;
            }

            .navbar .clock {
                grid-column: span 2;
            }
        }

        @media (max-width: 576px) {
            .botones-container {
                grid-template-columns: 1fr;
            }

            .boton {
                height: 90px;
                flex-direction: row;
                justify-content: flex-start;
                padding-left: 30px;
                gap: 20px;
            }

            .slogan-container {
                flex: 0 0 150px;
            }

            .navbar-actions {
                grid-template-columns: 1fr;
            }

            .navbar .clock {
                grid-column: span 1;
            }
        }

        @supports (-webkit-touch-callout: none) {
            .boton {
                backdrop-filter: none;
            }
        }
    </style>
</head>

<body>
    <div class="navbar">
        <div class="usuario-info">
            <i class="fas fa-user-circle"></i> Usuario:
            <strong><?php echo htmlspecialchars($usuario_nombre); ?></strong> | Rol:
            <strong><?php echo htmlspecialchars($tipo_usuario); ?></strong>
        </div>
        <div class="navbar-actions">
            <button class="clock" id="liveClock">
                <i class="fas fa-clock"></i> <span id="clockText">00:00:00</span>
            </button>
            <button class="modo-nocturno" id="toggleNightMode">
                <i class="fas fa-moon"></i> Modo Nocturno
            </button>
            <form action="cerrar_sesion.php" method="post">
                <button class="cerrar-sesion" type="submit">
                    <i class="fas fa-sign-out-alt"></i> Cerrar sesión
                </button>
            </form>
        </div>
    </div>

    <div class="main-content">
        <div class="slogan-container">
            <div class="slogan-image slogan-day"></div>
            <div class="slogan-image slogan-night"></div>
        </div>
        <div class="menu-container">
            <div class="botones-container">
                <button class="boton" onclick="location.href='inventario.php'"><i class="fas fa-boxes"></i>
                    Inventario</button>
                <button class="boton" onclick="location.href='clientes.php'"><i class="fas fa-users"></i>
                    Clientes</button>
                <button class="boton" onclick="location.href='proveedores.php'"><i class="fas fa-truck"></i>
                    Proveedores</button>
                    <button class="boton" onclick="location.href='ventas.php'"><i class="fas fa-dollar-sign"></i>
                    Ventas</button>
                <button class="boton" onclick="location.href='pedidos.php'"><i class="fas fa-truck"></i>
                    Pedidos</button>
                <button class="boton" onclick="location.href='gastos.php'"><i class="fas fa-receipt"></i>
                    Gastos</button>
                <button class="boton" onclick="location.href='cUsuario.php'"><i class="fas fa-user-cog"></i>
                    Usuarios</button>
                <button class="boton" onclick="location.href='reportes.php'"><i class="fas fa-chart-line"></i>
                    Reportes</button>
                <button class="boton" onclick="location.href='configuracion.php'"><i class="fas fa-cogs"></i>
                    Configuración</button>
                <button class="boton" onclick="location.href='configuracion.php'"><i class="fas fa-cogs"></i>
                    Acerca de..</button>

            </div>
        </div>
    </div>

    <script>
        // Función para alternar el modo nocturno
        const toggleNightMode = () => {
            document.body.classList.toggle('night-mode');
            // Guardar preferencia en localStorage
            const isNightMode = document.body.classList.contains('night-mode');
            localStorage.setItem('nightMode', isNightMode);

            // Cambiar icono y texto del botón
            const button = document.getElementById('toggleNightMode');
            if (isNightMode) {
                button.innerHTML = '<i class="fas fa-sun"></i> Modo Claro';
            } else {
                button.innerHTML = '<i class="fas fa-moon"></i> Modo Nocturno';
            }
        };

        // Función para actualizar el reloj
        function updateClock() {
            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            document.getElementById('clockText').textContent = `${hours}:${minutes}:${seconds}`;
        }

        // Verificar preferencia guardada al cargar la página
        document.addEventListener('DOMContentLoaded', () => {
            // Configurar modo nocturno
            const nightMode = localStorage.getItem('nightMode') === 'true';
            if (nightMode) {
                document.body.classList.add('night-mode');
                const button = document.getElementById('toggleNightMode');
                button.innerHTML = '<i class="fas fa-sun"></i> Modo Claro';
            }

            // Asignar evento al botón
            document.getElementById('toggleNightMode').addEventListener('click', toggleNightMode);

            // Iniciar reloj
            updateClock();
            setInterval(updateClock, 1000);
        });
    </script>
</body>

</html>