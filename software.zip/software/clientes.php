<?php
// conexion.php
$host = 'localhost';
$dbname = 'admin';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $id_cliente = $_POST['id_cliente'] ?? null;
    
    if ($action == 'guardar') {
        if (empty($id_cliente)) {
            // Insertar nuevo cliente
            $stmt = $conn->prepare("INSERT INTO clientes (nombre, apellido_P, apellido_M, telefono, direccion, correo, fecha_registro) 
                                  VALUES (?, ?, ?, ?, ?, ?, CURDATE())");
        } else {
            // Actualizar cliente existente
            $stmt = $conn->prepare("UPDATE clientes SET nombre=?, apellido_P=?, apellido_M=?, telefono=?, direccion=?, correo=?
                                  WHERE id_cliente=?");
        }
        
        $params = [
            $_POST['nombre'],
            $_POST['apellido_P'],
            $_POST['apellido_M'],
            $_POST['telefono'],
            $_POST['direccion'],
            $_POST['correo']
        ];
        
        if (!empty($id_cliente)) $params[] = $id_cliente;
        
        $stmt->execute($params);
    } elseif ($action == 'eliminar') {
        $stmt = $conn->prepare("DELETE FROM clientes WHERE id_cliente=?");
        $stmt->execute([$id_cliente]);
        
        header("Location: clientes.php?eliminado=1");
        exit;
    }
    
    header("Location: clientes.php");
    exit;
}

// Obtener clientes
$search = $_GET['search'] ?? '';

$query = "SELECT * FROM clientes WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (nombre LIKE ? OR apellido_P LIKE ? OR apellido_M LIKE ? OR correo LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%", "%$search%"]);
}

$query .= " ORDER BY fecha_registro DESC";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Clientes</title>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --light-color: #ecf0f1;
            --dark-color: #34495e;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color:rgb(111, 200, 232);
            color: #333;
        }
        
        .container {
            width: 95%;
            margin: 20px auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        
        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px;
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 10px;
        }
        
        .search-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .search-group {
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        
        .search-input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            min-width: 250px;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-danger {
            background-color: #e74c3c;
            color: white;
        }
        
        .btn-info {
            background-color: #17a2b8;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: var(--primary-color);
            color: white;
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #f1f1f1;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .action-btn {
            padding: 5px 10px;
            font-size: 14px;
            border-radius: 3px;
        }
        
        .footer-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
        
        .footer-btn {
            padding: 10px 20px;
            font-size: 16px;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .form-group input, 
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        
        .date-info {
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 5px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        
        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }

        @media (max-width: 768px) {
            .search-container {
                justify-content: center;
            }
            
            .search-group {
                flex-direction: column;
                width: 100%;
            }
            
            .search-input {
                width: 100%;
                min-width: auto;
            }
            
            .modal-content {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>GESTIÓN DE CLIENTES</h1>
        
        <?php if (isset($_GET['eliminado'])): ?>
        <div class="alert alert-success">
            Cliente eliminado correctamente.
        </div>
        <?php endif; ?>
        
        <!-- Barra de búsqueda mejorada -->
        <div class="search-container">
            <div class="search-group">
                <input type="text" class="search-input" placeholder="Buscar cliente..." id="searchInput"
                       value="<?= htmlspecialchars($search) ?>">
                
                <button class="btn btn-primary" onclick="searchClients()">Buscar</button>
                <button class="btn btn-secondary" onclick="clearSearch()">Limpiar</button>
            </div>
        </div>
        
        <!-- Tabla de clientes -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Teléfono</th>
                    <th>Correo</th>
                    <th>Fecha Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($clientes as $cliente): ?>
                <tr>
                    <td><?= $cliente['id_cliente'] ?></td>
                    <td><?= htmlspecialchars($cliente['nombre']) ?></td>
                    <td><?= htmlspecialchars($cliente['apellido_P']) ?></td>
                    <td><?= htmlspecialchars($cliente['apellido_M']) ?></td>
                    <td><?= htmlspecialchars($cliente['telefono']) ?></td>
                    <td><?= htmlspecialchars($cliente['correo']) ?></td>
                    <td><?= $cliente['fecha_registro'] ?></td>
                    <td class="action-buttons">
                        <button class="btn btn-primary action-btn" 
                                onclick="openEditModal(
                                    <?= $cliente['id_cliente'] ?>,
                                    '<?= addslashes($cliente['nombre']) ?>',
                                    '<?= addslashes($cliente['apellido_P']) ?>',
                                    '<?= addslashes($cliente['apellido_M']) ?>',
                                    '<?= addslashes($cliente['telefono']) ?>',
                                    '<?= addslashes($cliente['direccion']) ?>',
                                    '<?= addslashes($cliente['correo']) ?>'
                                )">
                            Editar
                        </button>
                        <form method="POST" style="display: inline-block;">
                            <input type="hidden" name="action" value="eliminar">
                            <input type="hidden" name="id_cliente" value="<?= $cliente['id_cliente'] ?>">
                            <button type="submit" class="btn btn-danger action-btn" onclick="return confirm('¿Está seguro de eliminar este cliente?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Botones inferiores -->
        <div class="footer-buttons">
            <a href="principal.php" class="btn btn-info footer-btn">Regresar al Principal</a>
            <div>
                <button class="btn btn-primary footer-btn" onclick="openAddModal()">Registrar Cliente</button>
                <button class="btn btn-secondary footer-btn" onclick="window.location.reload()">Actualizar Lista</button>
            </div>
        </div>
    </div>
    
    <!-- Modal para agregar/editar clientes -->
    <div id="clientModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2 id="modalTitle">Nuevo Cliente</h2>
            
            <form id="clientForm" method="POST">
                <input type="hidden" name="action" id="formAction" value="guardar">
                <input type="hidden" name="id_cliente" id="id_cliente" value="">
                
                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" required>
                </div>
                
                <div class="form-group">
                    <label for="apellido_P">Apellido Paterno:</label>
                    <input type="text" id="apellido_P" name="apellido_P" required>
                </div>
                
                <div class="form-group">
                    <label for="apellido_M">Apellido Materno:</label>
                    <input type="text" id="apellido_M" name="apellido_M">
                </div>
                
                <div class="form-group">
                    <label for="telefono">Teléfono:</label>
                    <input type="tel" id="telefono" name="telefono" required>
                </div>
                
                <div class="form-group">
                    <label for="direccion">Dirección:</label>
                    <textarea id="direccion" name="direccion" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="correo">Correo Electrónico:</label>
                    <input type="email" id="correo" name="correo" required>
                </div>
                
                <div class="date-info">
                    <span id="fechaRegistroText"></span>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-danger" onclick="closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Funciones para manejar los modales
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Nuevo Cliente';
            document.getElementById('formAction').value = 'guardar';
            document.getElementById('id_cliente').value = '';
            document.getElementById('fechaRegistroText').textContent = 'Se registrará con la fecha actual';
            document.getElementById('clientForm').reset();
            document.getElementById('clientModal').style.display = 'block';
        }
        
        function openEditModal(id, nombre, apellidoP, apellidoM, telefono, direccion, correo) {
            document.getElementById('modalTitle').textContent = 'Editar Cliente';
            document.getElementById('formAction').value = 'guardar';
            document.getElementById('id_cliente').value = id;
            document.getElementById('nombre').value = nombre;
            document.getElementById('apellido_P').value = apellidoP;
            document.getElementById('apellido_M').value = apellidoM;
            document.getElementById('telefono').value = telefono;
            document.getElementById('direccion').value = direccion;
            document.getElementById('correo').value = correo;
            document.getElementById('fechaRegistroText').textContent = 'Fecha de registro no modificable';
            
            document.getElementById('clientModal').style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('clientModal').style.display = 'none';
        }
        
        function searchClients() {
            const searchValue = document.getElementById('searchInput').value;
            window.location.href = `?search=${encodeURIComponent(searchValue)}`;
        }
        
        function clearSearch() {
            window.location.href = '?';
        }
        
        // Cerrar modal al hacer clic fuera del contenido
        window.onclick = function(event) {
            const modal = document.getElementById('clientModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>