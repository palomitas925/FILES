<?php
// Configuración de la base de datos
$db_config = [
    'servername' => 'localhost',
    'username' => 'root',
    'password' => '',
    'dbname' => 'admin'
];

// Establecer conexión
function getDBConnection() {
    global $db_config;
    $conn = new mysqli($db_config['servername'], $db_config['username'], $db_config['password'], $db_config['dbname']);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    return $conn;
}

// Obtener datos de ventas con información de pedidos
function getVentas() {
    $conn = getDBConnection();
    $sql = "SELECT v.id_venta, v.id_pedido, v.fecha_venta, v.monto_total, v.metodo_pago, v.comprobante,
                   pr.nombre_producto as producto, dp.cantidad, c.nombre as cliente
            FROM Ventas v
            JOIN Pedidos p ON v.id_pedido = p.id_pedido
            JOIN DetallePedidos dp ON p.id_pedido = dp.id_pedido
            JOIN productos pr ON dp.id_producto = pr.id_producto
            JOIN Clientes c ON p.id_cliente = c.id_cliente
            ORDER BY v.fecha_venta DESC";
    $result = $conn->query($sql);
    $ventas = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $ventas[] = $row;
        }
    }
    $conn->close();
    return $ventas;
}

$ventas = getVentas();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Ventas - Datos Reales</title>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #34495e;
            --accent-color: #3498db;
            --light-color: #ecf0f1;
            --danger-color: #e74c3c;
            --success-color: #2ecc71;
            --border-radius: 4px;
            --box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--light-color);
        }
        
        .search-bar {
            display: flex;
            margin-bottom: 20px;
            gap: 10px;
        }
        
        .search-bar input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
        }
        
        .search-bar button {
            padding: 10px 20px;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-search {
            background-color: var(--accent-color);
            color: white;
        }
        
        .btn-clear {
            background-color: var(--light-color);
            color: var(--secondary-color);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: var(--primary-color);
            color: white;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .action-btns {
            display: flex;
            gap: 5px;
        }
        
        .btn-edit {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-delete {
            background-color: var(--danger-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .footer-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        
        .btn-main {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-add {
            background-color: var(--success-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        .btn-refresh {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--border-radius);
            cursor: pointer;
        }
        
        hr {
            border: 0;
            height: 1px;
            background-color: #ddd;
            margin: 20px 0;
        }
        
        .no-data {
            text-align: center;
            padding: 20px;
            color: #777;
            font-style: italic;
        }
   </style>
</head>
<body>
    <div class="container">
        <h1>GESTIÓN DE VENTAS</h1>
        
        <div class="search-bar">
            <input type="text" id="search-input" placeholder="Buscar venta...">
            <button class="btn-search" id="btn-search">Buscar</button>
            <button class="btn-clear" id="btn-clear">Limpiar</button>
        </div>
        
        <hr>
        
        <table id="ventas-table">
            <thead>
                <tr>
                    <th>ID Venta</th>
                    <th>ID Pedido</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Monto</th>
                    <th>Método Pago</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php if (count($ventas) > 0): ?>
                    <?php foreach ($ventas as $venta): ?>
                        <tr data-id="<?= $venta['id_venta'] ?>">
                            <td><?= htmlspecialchars($venta['id_venta']) ?></td>
                            <td><?= htmlspecialchars($venta['id_pedido']) ?></td>
                            <td><?= htmlspecialchars($venta['cliente']) ?></td>
                            <td><?= htmlspecialchars($venta['fecha_venta']) ?></td>
                            <td><?= htmlspecialchars($venta['producto']) ?></td>
                            <td><?= htmlspecialchars($venta['cantidad']) ?></td>
                            <td>$<?= number_format($venta['monto_total'], 2) ?></td>
                            <td><?= htmlspecialchars($venta['metodo_pago']) ?></td>
                            <td class="action-btns">
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="no-data">No se encontraron ventas registradas</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div class="footer-actions">
            <button class="btn-main" onclick="window.location.href='principal.php'">Regresar al Principal</button>
            <div>
                <button class="btn-refresh" onclick="actualizarTabla()">Actualizar Lista</button>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('btn-search').addEventListener('click', function() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const rows = document.querySelectorAll('#ventas-table tbody tr');
            let hasResults = false;
            
            rows.forEach(row => {
                if (row.classList.contains('no-data')) {
                    row.style.display = 'none';
                    return;
                }
                
                let found = false;
                const cells = row.querySelectorAll('td');
                
                row.style.display = found ? '' : 'none';
            });
            
            // Mostrar mensaje si no hay resultados
            const noDataRow = document.querySelector('#ventas-table .no-data');
            if (!hasResults && !noDataRow) {
                const tbody = document.querySelector('#ventas-table tbody');
                tbody.innerHTML = '<tr><td colspan="9" class="no-data">No se encontraron resultados</td></tr>';
            } else if (hasResults && noDataRow) {
                noDataRow.remove();
            }
        });

        document.getElementById('btn-clear').addEventListener('click', function() {
            document.getElementById('search-input').value = '';
            const rows = document.querySelectorAll('#ventas-table tbody tr');
            let hasData = false;
            
            rows.forEach(row => {
                if (!row.classList.contains('no-data')) {
                    row.style.display = '';
                    hasData = true;
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Si no hay datos, mostrar mensaje
            if (!hasData) {
                const tbody = document.querySelector('#ventas-table tbody');
                tbody.innerHTML = '<tr><td colspan="9" class="no-data">No se encontraron ventas registradas</td></tr>';
            }
        });

        function actualizarTabla() {
            location.reload();
        }
    </script>
</body>
</html>